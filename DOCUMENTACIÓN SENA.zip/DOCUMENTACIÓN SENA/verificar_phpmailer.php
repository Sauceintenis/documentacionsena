<?php
// Script para verificar que PHPMailer esté correctamente instalado

echo "<h1>🔍 Verificación de PHPMailer</h1>";

// Verificar si los archivos existen
$archivos_phpmailer = [
    'PHPMailer/src/PHPMailer.php',
    'PHPMailer/src/SMTP.php',
    'PHPMailer/src/Exception.php'
];

echo "<h2>📁 Verificación de Archivos:</h2>";
$todos_existen = true;

foreach ($archivos_phpmailer as $archivo) {
    if (file_exists($archivo)) {
        echo "✅ <strong>$archivo</strong> - Existe<br>";
    } else {
        echo "❌ <strong>$archivo</strong> - NO EXISTE<br>";
        $todos_existen = false;
    }
}

if ($todos_existen) {
    echo "<br><h2>🧪 Prueba de Carga de Clases:</h2>";
    
    try {
        require_once 'PHPMailer/src/PHPMailer.php';
        require_once 'PHPMailer/src/SMTP.php';
        require_once 'PHPMailer/src/Exception.php';
        
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        
        $mail = new PHPMailer(true);
        echo "✅ <strong>PHPMailer se cargó correctamente</strong><br>";
        echo "📊 <strong>Versión:</strong> " . PHPMailer::VERSION . "<br>";
        
        echo "<br><h2>⚙️ Configuración de Prueba:</h2>";
        echo "<div style='background: #f0f0f0; padding: 15px; border-radius: 5px;'>";
        echo "<strong>Para configurar tu correo, edita estos archivos:</strong><br>";
        echo "• <code>Controlador/nuevo.php</code> (líneas 67-68)<br>";
        echo "• <code>CRUDS/Administrador/enviar_notificacion.php</code> (líneas 35-36)<br><br>";
        echo "<strong>Cambia:</strong><br>";
        echo "<code>\$mail->Username = 'tu_correo@gmail.com';</code><br>";
        echo "<code>\$mail->Password = 'tu_contraseña_app';</code><br>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "❌ <strong>Error al cargar PHPMailer:</strong> " . $e->getMessage() . "<br>";
    }
} else {
    echo "<br><h2>📥 Instrucciones de Instalación:</h2>";
    echo "<div style='background: #ffe6e6; padding: 15px; border-radius: 5px;'>";
    echo "<strong>1.</strong> Descarga PHPMailer desde: <a href='https://github.com/PHPMailer/PHPMailer/releases' target='_blank'>GitHub</a><br>";
    echo "<strong>2.</strong> Extrae el archivo descargado<br>";
    echo "<strong>3.</strong> Copia la carpeta 'src' dentro de una carpeta llamada 'PHPMailer' en tu proyecto<br>";
    echo "<strong>4.</strong> La estructura debe ser: <code>tu-proyecto/PHPMailer/src/</code><br>";
    echo "</div>";
}

echo "<br><h2>🔧 Estado del Sistema:</h2>";
echo "📍 <strong>Ruta actual:</strong> " . __DIR__ . "<br>";
echo "🐘 <strong>Versión PHP:</strong> " . PHP_VERSION . "<br>";
echo "📧 <strong>Función mail() disponible:</strong> " . (function_exists('mail') ? 'Sí' : 'No') . "<br>";

echo "<br><div style='background: #e8f5e9; padding: 15px; border-radius: 5px;'>";
echo "<strong>💡 Próximos pasos:</strong><br>";
echo "1. Ejecuta el script SQL para crear la tabla de encadenamiento<br>";
echo "2. Configura tus credenciales de Gmail en los archivos PHP<br>";
echo "3. Prueba el registro de un usuario para verificar el envío de correos<br>";
echo "</div>";
?>
