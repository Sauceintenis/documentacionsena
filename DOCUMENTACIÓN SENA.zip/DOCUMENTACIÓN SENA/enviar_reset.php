<?php
// enviar_reset.php
session_start();
require_once 'Conexion/abrir_conexion.php';

// Incluir PHPMailer desde la carpeta del proyecto
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';
require __DIR__ . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Verificar CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_reset'] ?? '')) {
    header("Location: olvidaste.php?msg=invalid");
    exit;
}

// Correo recibido
$correo = trim($_POST['correo'] ?? '');
if (empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    header("Location: olvidaste.php?msg=invalid");
    exit;
}

// Buscar usuario por correo
$stmt = $conexion->prepare("SELECT Id_registro, Nombre, Apellidos FROM registro WHERE Correo = ?");
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // ✅ Mensaje genérico (no revela si el correo existe)
    header("Location: olvidaste.php?msg=sent");
    exit;
}

$user = $result->fetch_assoc();
$stmt->close();

// Generar token seguro
$token   = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', time() + 3600); // válido 1 hora

// Limpiar tokens previos de ese usuario
$stmt = $conexion->prepare("DELETE FROM password_resets WHERE usuario_id = ?");
$stmt->bind_param("i", $user['Id_registro']);
$stmt->execute();
$stmt->close();

// Guardar nuevo token
$stmt = $conexion->prepare("INSERT INTO password_resets (usuario_id, token, fecha_expiracion) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $user['Id_registro'], $token, $expires);
$stmt->execute();
$stmt->close();

// Enlace para reset
$url = sprintf(
    "%s/reset_password.php?token=%s",
    (isset($_SERVER['HTTPS']) ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']),
    $token
);

// Configuración de PHPMailer
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'sistemadocumentacionsena@gmail.com';  // ✅ tu correo real
    $mail->Password   = 'mupn bxwb napb lksy';                 // ✅ tu app password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Remitente y destinatario
    $mail->setFrom('sistemadocumentacionsena@gmail.com', 'Sistema SENA');
    $mail->addAddress($correo, $user['Nombre'] . ' ' . $user['Apellidos']);

    // Contenido
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->Subject = '🔑 Recuperación de contraseña';

    // Plantilla HTML bonita
    $nombre_completo = $user['Nombre'] . ' ' . $user['Apellidos'];
    $mail->Body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f4f7f6; margin:0; padding:0; }
            .container { max-width: 600px; margin: 20px auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1);}
            .header { background: linear-gradient(135deg, #2196f3, #21cbf3); color: #fff; padding: 30px; text-align: center; }
            .header h1 { margin: 0; font-size: 26px; }
            .content { padding: 30px; color: #333; }
            .content h2 { margin-top: 0; color: #2196f3; }
            .btn { display: inline-block; background: #2196f3; color: #fff; padding: 14px 28px; margin: 20px 0; text-decoration: none; border-radius: 6px; font-weight: bold; }
            .btn:hover { background: #1976d2; }
            .footer { background: #eeeeee; color: #555; padding: 20px; text-align: center; font-size: 13px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🔑 Recuperación de Contraseña</h1>
            </div>
            <div class='content'>
                <h2>Hola, $nombre_completo</h2>
                <p>Hemos recibido una solicitud para restablecer tu contraseña.</p>
                <p>Haz clic en el botón de abajo para continuar con el proceso:</p>
                <p style='text-align:center;'>
                    <a href='$url' class='btn'>Restablecer contraseña</a>
                </p>
                <p>Este enlace expirará en <strong>1 hora</strong>.</p>
                <p>Si no solicitaste este cambio, puedes ignorar este mensaje.</p>
            </div>
            <div class='footer'>
                <p><strong>Sistema de Documentación SENA</strong></p>
                <p>Este es un correo automático, por favor no responder.</p>
                <p>&copy; ".date('Y')." SENA - Todos los derechos reservados</p>
            </div>
        </div>
    </body>
    </html>";

    // Texto alternativo (para clientes que no leen HTML)
    $mail->AltBody = "Hola {$user['Nombre']},\n\nPara restablecer tu contraseña visita este enlace: $url\n\nEl enlace expira en 1 hora.\n\nSi no solicitaste este cambio, ignora este correo.";

    $mail->send();
    header("Location: olvidaste.php?msg=sent");
    exit;
} catch (Exception $e) {
    error_log("Error PHPMailer: {$mail->ErrorInfo}");
    header("Location: olvidaste.php?msg=error");
    exit;
}
