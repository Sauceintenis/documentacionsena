<?php
session_start();

// Si existe una cookie de "recordar sesión", la eliminamos
if (isset($_COOKIE['remember_me'])) {
    // 1. Limpiar la cookie
    setcookie('remember_me', '', time() - 3600, '/');

    // 2. Limpiar los tokens de la base de datos para mayor seguridad
    $conexion = mysqli_connect("localhost", "root", "", "documentacion_sena");
    if ($conexion && isset($_SESSION['Id_registro'])) {
        $sql = "UPDATE registro SET remember_selector = NULL, remember_token_hash = NULL, remember_expires = NULL WHERE Id_registro = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "i", $_SESSION['Id_registro']);
        mysqli_stmt_execute($stmt);
        mysqli_close($conexion);
    }
}

// 3. Destruir la sesión
$_SESSION = array();
session_destroy();

// 4. Redirigir al inicio de sesión con un mensaje de éxito
header("Location: index.php?success=Sesión cerrada correctamente");
exit();
?>
