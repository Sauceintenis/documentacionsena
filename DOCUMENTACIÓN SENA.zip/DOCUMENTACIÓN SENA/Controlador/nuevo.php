<?php
require_once '../Conexion/abrir_conexion.php';

// Incluir PHPMailer siempre al inicio
require_once '../PHPMailer/src/PHPMailer.php';
require_once '../PHPMailer/src/SMTP.php';
require_once '../PHPMailer/src/Exception.php';

// Declaraciones use al nivel superior
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Verificar si PHPMailer está disponible
$phpmailer_disponible = class_exists('PHPMailer\PHPMailer\PHPMailer');

// Recoger datos del formulario
$nombre = $_POST['Nombre'] ?? '';
$apellidos = $_POST['Apellidos'] ?? '';
$tipo_doc = $_POST['tipo_documento'] ?? '';
$num_doc = $_POST['numero_documento'] ?? '';
$correo = $_POST['Correo'] ?? '';
$direccion = $_POST['Direccion_contacto'] ?? '';
$pass = $_POST['Contraseña'] ?? '';
$programa_id = $_POST['programa_id'] ?? null;

// Determinar si es menor de edad basado en el tipo de documento
$es_menor_edad = ($tipo_doc === 'TI') ? 'si' : 'no';

// Datos del representante (solo si es menor de edad)
$nombre_rep = null;
$tipo_doc_rep = null;
$num_doc_rep = null;
if ($es_menor_edad === 'si') {
    $nombre_rep = trim(($_POST['representante_nombre'] ?? '') . ' ' . ($_POST['representante_apellidos'] ?? ''));
    $tipo_doc_rep = $_POST['representante_tipo_documento'] ?? null;
    $num_doc_rep = $_POST['representante_numero_documento'] ?? null;
}

// Verificar si el correo o el número de documento ya existen
$verificar_correo = mysqli_query($conexion, "SELECT * FROM registro WHERE Correo = '$correo'");
$verificar_documento = mysqli_query($conexion, "SELECT * FROM registro WHERE numero_documento = '$num_doc'");

if(mysqli_num_rows($verificar_correo) > 0) {
    echo "<script>
            alert('El correo ya está registrado. Por favor, usa otro.');
            window.location = '../Registro.php';
        </script>";
    exit();
} else if(mysqli_num_rows($verificar_documento) > 0) {
    echo "<script>
            alert('El número de documento ya está registrado. Por favor, verifica tus datos.');
            window.location = '../Registro.php';
        </script>";
    exit();
} else {
    // Hashear la contraseña
    $pass_cifrado = password_hash($pass, PASSWORD_DEFAULT);
    
    // Insertar usuario en la base de datos
    $insertar = mysqli_query($conexion, "INSERT INTO registro 
        (Nombre, Apellidos, tipo_documento, numero_documento, Correo, Direccion_contacto, Contraseña, Rol, es_menor_edad, nombre_completo_representante, tipo_documento_representante, numero_documento_representante, programa_id) 
        VALUES 
        ('$nombre', '$apellidos', '$tipo_doc', '$num_doc', '$correo', '$direccion', '$pass_cifrado', 1, '$es_menor_edad', '$nombre_rep', '$tipo_doc_rep', '$num_doc_rep', '$programa_id')");

    if($insertar) {
        // Si el registro fue exitoso, intentar enviar correo
        if ($phpmailer_disponible) {
            if(enviarCorreoBienvenida($correo, $nombre, $apellidos, $num_doc, $es_menor_edad, $nombre_rep, $programa_id, $conexion)) {
                echo "<script>
                        alert('¡Registro exitoso! Se ha enviado un correo de confirmación a tu email.');
                        window.location = '../index.php';
                    </script>";
            } else {
                echo "<script>
                        alert('Registro exitoso, pero no se pudo enviar el correo de confirmación. Revisa la configuración de PHPMailer.');
                        window.location = '../index.php';
                    </script>";
            }
        } else {
            echo "<script>
                    alert('Registro exitoso. PHPMailer no está disponible, por lo que no se envió correo de confirmación.');
                    window.location = '../index.php';
                </script>";
        }
    } else {
        echo "<script>
                alert('Error al registrar usuario. Inténtalo de nuevo.');
                window.location = '../Registro.php';
            </script>";
    }
}

include("../Conexion/cerrar_conexion.php");

function enviarCorreoBienvenida($correo_destino, $nombre, $apellidos, $numero_documento, $es_menor, $nombre_representante, $programa_id, $conexion) {
    $mail = new PHPMailer(true);

    try {
        // Obtener información del programa
        $programa_info = "No asignado";
        if ($programa_id) {
            $query_programa = mysqli_query($conexion, "SELECT nombre_programa, nivel_formacion, jornada FROM programas_formacion WHERE id = $programa_id");
            if ($programa_data = mysqli_fetch_assoc($query_programa)) {
                $programa_info = $programa_data['nombre_programa'] . " - " . $programa_data['nivel_formacion'] . " (" . $programa_data['jornada'] . ")";
            }
        }

        // ✅ CONFIGURACIÓN SMTP CON TUS CREDENCIALES
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'sistemadocumentacionsena@gmail.com';  // ✅ Tu correo
        $mail->Password   = 'mupn bxwb napb lksy';                 // ✅ Tu contraseña de aplicación
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // Configuración adicional para debugging
        $mail->SMTPDebug = 0; // Cambiar a 2 para ver errores detallados
        $mail->Debugoutput = 'html';

        // Configuración del correo
        $mail->setFrom('sistemadocumentacionsena@gmail.com', 'Sistema SENA'); // ✅ Tu correo
        $mail->addAddress($correo_destino, $nombre . ' ' . $apellidos);

        // Contenido del correo
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = '✅ ¡Bienvenido al Sistema SENA!';
        
        $nombre_completo = $nombre . ' ' . $apellidos;
        $fecha_actual = date('d/m/Y H:i');
        
        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background-color: #f4f7f6; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #4caf50, #81c784); color: white; padding: 30px; text-align: center; }
                .header h1 { margin: 0; font-size: 28px; }
                .header p { margin: 10px 0 0 0; font-size: 16px; opacity: 0.9; }
                .content { padding: 30px; }
                .welcome-box { background: #e8f5e9; border-left: 4px solid #4caf50; padding: 20px; margin: 20px 0; border-radius: 8px; }
                .info-section { background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .info-section h3 { color: #2e7d32; margin-top: 0; }
                .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
                .info-item:last-child { border-bottom: none; }
                .info-label { font-weight: bold; color: #555; }
                .info-value { color: #333; }
                .next-steps { background: #fff3e0; border-left: 4px solid #ff9800; padding: 20px; margin: 20px 0; border-radius: 8px; }
                .next-steps h3 { color: #f57c00; margin-top: 0; }
                .next-steps ol { padding-left: 20px; }
                .next-steps li { margin-bottom: 10px; }
                .footer { background: #2e7d32; color: white; padding: 20px; text-align: center; font-size: 14px; }
                .footer p { margin: 5px 0; }
                .btn { display: inline-block; background: #4caf50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>¡Bienvenido al SENA!</h1>
                    <p>Tu registro se ha completado exitosamente</p>
                </div>
                
                <div class='content'>
                    <div class='welcome-box'>
                        <h2>🎉 ¡Felicitaciones, $nombre_completo!</h2>
                        <p>Tu cuenta ha sido creada exitosamente en el Sistema de Documentación del SENA. Ya puedes acceder a tu panel de aprendiz y comenzar a gestionar tus documentos.</p>
                    </div>
                    
                    <div class='info-section'>
                        <h3>📋 Información de tu Registro</h3>
                        <div class='info-item'>
                            <span class='info-label'>Nombre Completo:</span>
                            <span class='info-value'>$nombre_completo</span>
                        </div>
                        <div class='info-item'>
                            <span class='info-label'>Número de Documento:</span>
                            <span class='info-value'>$numero_documento</span>
                        </div>
                        <div class='info-item'>
                            <span class='info-label'>Correo Electrónico:</span>
                            <span class='info-value'>$correo_destino</span>
                        </div>
                        <div class='info-item'>
                            <span class='info-label'>Programa de Formación:</span>
                            <span class='info-value'>$programa_info</span>
                        </div>
                        <div class='info-item'>
                            <span class='info-label'>Fecha de Registro:</span>
                            <span class='info-value'>$fecha_actual</span>
                        </div>
                        <div class='info-item'>
                            <span class='info-label'>Tipo de Usuario:</span>
                            <span class='info-value'>Aprendiz SENA</span>
                        </div>";
        
        if ($es_menor === 'si' && !empty($nombre_representante)) {
            $mail->Body .= "
                        <div class='info-item'>
                            <span class='info-label'>Representante Legal:</span>
                            <span class='info-value'>$nombre_representante</span>
                        </div>";
        }
        
        $mail->Body .= "
                    </div>
                    
                    <div class='next-steps'>
                        <h3>📝 Próximos Pasos</h3>
                        <ol>
                            <li><strong>Inicia Sesión:</strong> Usa tu número de documento ($numero_documento) y tu contraseña para acceder al sistema.</li>
                            <li><strong>Completa tu Perfil:</strong> Revisa y actualiza tu información personal si es necesario.</li>
                            <li><strong>Sube tus Documentos:</strong> Carga los documentos requeridos (Registro Civil, Documento de Identidad, EPS).</li>";
        
        if ($es_menor === 'si') {
            $mail->Body .= "<li><strong>Firmas Digitales:</strong> Como eres menor de edad, necesitarás subir tanto tu firma como la de tu representante legal.</li>";
        } else {
            $mail->Body .= "<li><strong>Firma Digital:</strong> Sube tu firma digital para completar los documentos oficiales.</li>";
        }
        
        $mail->Body .= "
                            <li><strong>Genera tus Documentos:</strong> Una vez completado todo, podrás generar y descargar tus documentos oficiales.</li>
                        </ol>
                    </div>
                    
                    <div style='text-align: center; margin: 30px 0;'>
                        <p style='background: #e3f2fd; padding: 15px; border-radius: 8px; border-left: 3px solid #2196f3;'>
                            <strong>🔑 Para iniciar sesión usa:</strong><br>
                            <strong>Documento:</strong> $numero_documento<br>
                            <strong>Contraseña:</strong> La que acabas de crear
                        </p>
                    </div>
                    
                    <div style='background: #f1f8e9; padding: 20px; border-radius: 8px; margin: 20px 0;'>
                        <h3 style='color: #2e7d32; margin-top: 0;'>💡 Consejos Importantes</h3>
                        <ul>
                            <li>Guarda este correo para futuras referencias</li>
                            <li>Usa siempre tu número de documento para iniciar sesión</li>
                            <li>Mantén tu contraseña segura y no la compartas</li>
                            <li>Sube documentos únicamente en formato PDF (máximo 5MB)</li>
                            <li>Las firmas deben ser imágenes claras (PNG, JPG)</li>
                        </ul>
                    </div>
                </div>
                
                <div class='footer'>
                    <p><strong>Servicio Nacional de Aprendizaje - SENA</strong></p>
                    <p>Sistema de Documentación Digital</p>
                    <p>Este es un correo automático, por favor no responder.</p>
                    <p>&copy; " . date('Y') . " SENA - Todos los derechos reservados</p>
                </div>
            </div>
        </body>
        </html>";

        $mail->send();
        return true;
        
    } catch (Exception $e) {
        // Log del error para debugging
        error_log("Error PHPMailer: " . $mail->ErrorInfo);
        error_log("Exception: " . $e->getMessage());
        return false;
    }
}
?>
