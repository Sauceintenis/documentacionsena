<?php
require_once 'incluidos/verificar_login.php';
require_once 'Conexion/abrir_conexion.php';

// Obtener lista de programas disponibles
$query = "SELECT id, nombre_programa, nivel_formacion, jornada FROM programas_formacion";
$result = $conexion->query($query);
$programas = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Aprendiz - SENA</title>
    <link rel="stylesheet" href="CSS/Estilos.css">
</head>
<body class="register-page">
    <div class="register-container">
        <div class="register-header">
            <div class="sena-logo">
                <img src="IMG/Logo.png" alt="SENA Sofia Plus Logo">
            </div>
            <h1 class="register-title">Registro de Aprendiz</h1>
            <p class="register-subtitle">Completa el formulario para crear tu cuenta</p>
        </div>
        
        <form action="Controlador/nuevo.php" method="post">
            <!-- Datos del Aprendiz -->
            <div class="form-section">
                <h3 class="section-title">Datos del Aprendiz</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label for="tipo_documento">Tipo de Documento</label>
                        <select name="tipo_documento" id="tipo_documento" required>
                            <option value="" disabled selected>Seleccione...</option>
                            <option value="CC">Cédula de Ciudadanía</option>
                            <option value="TI">Tarjeta de Identidad</option>
                            <option value="CE">Cédula de Extranjería</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="numero_documento">Número de Documento</label>
                        <input type="number" id="numero_documento" name="numero_documento" placeholder="Número de Documento" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="Nombre">Nombres</label>
                        <input type="text" id="Nombre" name="Nombre" placeholder="Nombres" required>
                    </div>
                    <div class="form-group">
                        <label for="Apellidos">Apellidos</label>
                        <input type="text" id="Apellidos" name="Apellidos" placeholder="Apellidos" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="Correo">Correo Electrónico</label>
                        <input type="email" id="Correo" name="Correo" placeholder="Correo Electrónico" required>
                    </div>
                    <div class="form-group">
                        <label for="Contraseña">Contraseña</label>
                        <input type="password" id="Contraseña" name="Contraseña" placeholder="Contraseña" required>
                    </div>
                </div>
            </div>

            <!-- Programa de Formación -->
            <div class="form-section">
                <h3 class="section-title">Programa de Formación</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label for="programa_id">Selecciona tu programa</label>
                        <select name="programa_id" id="programa_id" required>
                            <option value="" disabled selected>Seleccione un programa...</option>
                            <?php foreach ($programas as $p): ?>
                                <option value="<?php echo $p['id']; ?>">
                                    <?php echo $p['nombre_programa'] . " - " . $p['nivel_formacion'] . " (" . $p['jornada'] . ")"; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Representante Legal -->
            <div id="representante_section" class="form-section" style="display: none;">
                <h3 class="section-title">Representante Legal</h3>
                <div id="datos_representante">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="representante_tipo_documento">Tipo de Documento del Representante</label>
                            <select id="representante_tipo_documento" name="representante_tipo_documento">
                                <option value="" disabled selected>Seleccione...</option>
                                <option value="CC">Cédula de Ciudadanía</option>
                                <option value="CE">Cédula de Extranjería</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="representante_numero_documento">Número de Documento del Representante</label>
                            <input type="number" id="representante_numero_documento" name="representante_numero_documento" placeholder="Número de Documento">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="representante_nombre">Nombres del Representante</label>
                            <input type="text" id="representante_nombre" name="representante_nombre" placeholder="Nombres">
                        </div>
                        <div class="form-group">
                            <label for="representante_apellidos">Apellidos del Representante</label>
                            <input type="text" id="representante_apellidos" name="representante_apellidos" placeholder="Apellidos">
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-save">Registrarse</button>
        </form>
        <div class="login-link">
            <p>¿Ya tienes una cuenta? <a href="index.php">Inicia sesión aquí</a></p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const tipoDocumento = document.getElementById('tipo_documento');
            const representanteSection = document.getElementById('representante_section');
            const representanteInputs = representanteSection.querySelectorAll('input, select');

            tipoDocumento.addEventListener('change', function () {
                if (this.value === 'TI') {
                    representanteSection.style.display = 'block';
                    representanteInputs.forEach(input => input.required = true);
                } else {
                    representanteSection.style.display = 'none';
                    representanteInputs.forEach(input => {
                        input.required = false;
                        input.value = '';
                    });
                }
            });
        });
    </script>
</body>
</html>
