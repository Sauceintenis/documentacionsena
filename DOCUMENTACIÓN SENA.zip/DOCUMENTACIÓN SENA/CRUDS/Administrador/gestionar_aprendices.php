<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
// Verificar que sea administrador
if ($_SESSION['Rol'] != 2) { 
    header('Location: ../../index.php'); 
    exit(); 
}

require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

// Obtener todos los aprendices con información de documentos y programas
$query = "SELECT 
    r.Id_registro,
    r.Nombre,
    r.Apellidos,
    r.Correo,
    r.fecha_registro,
    p.nombre_programa,
    p.nivel_formacion,
    p.jornada,
    CASE 
        WHEN a.usuario_id IS NOT NULL THEN 'Con documentos'
        ELSE 'Sin documentos'
    END as estado_documentos,
    COUNT(n.id) as notificaciones_pendientes
FROM registro r
LEFT JOIN aprendiz_sena a ON r.Id_registro = a.usuario_id
LEFT JOIN programas_formacion p ON r.programa_id = p.id
LEFT JOIN notificaciones n ON r.Id_registro = n.usuario_id AND n.leida = 0
WHERE r.Rol = 1
GROUP BY r.Id_registro, r.Nombre, r.Apellidos, r.Correo, r.fecha_registro, p.nombre_programa, p.nivel_formacion, p.jornada, a.usuario_id
ORDER BY r.fecha_registro DESC";

$result = $conexion->query($query);
$aprendices = $result->fetch_all(MYSQLI_ASSOC);

// Estadísticas rápidas
$total_aprendices = count($aprendices);
$con_documentos = count(array_filter($aprendices, fn($a) => $a['estado_documentos'] === 'Con documentos'));
$sin_documentos = $total_aprendices - $con_documentos;

// Obtener lista de programas para el filtro
$programas = $conexion->query("SELECT id, nombre_programa FROM programas_formacion ORDER BY nombre_programa");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Aprendices - SENA Admin</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
    <style>
        .aprendices-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
            border-left: 4px solid #4caf50;
        }

        .summary-card h3 {
            font-size: 28px;
            color: #4caf50;
            margin-bottom: 10px;
        }

        .summary-card p {
            color: #666;
            font-weight: bold;
        }

        .filters-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .filters-row {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .filter-group label {
            font-weight: bold;
            color: #333;
            font-size: 14px;
        }

        .filter-input {
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .filter-input:focus {
            border-color: #4caf50;
            outline: none;
        }

        .btn-filter {
            background: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease;
            height: fit-content;
            align-self: end;
        }

        .btn-filter:hover {
            background: #45a049;
        }

        .aprendices-table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .table-header {
            background: #4caf50;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            margin: 0;
            font-size: 20px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #f8f9fa;
            font-weight: bold;
            color: #333;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status-con-docs {
            background: #d4edda;
            color: #155724;
        }

        .status-sin-docs {
            background: #fff3cd;
            color: #856404;
        }

        .notification-badge {
            background: #ff4444;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 11px;
            font-weight: bold;
            min-width: 18px;
            text-align: center;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-view {
            background: #2196F3;
            color: white;
        }

        .btn-view:hover {
            background: #1976D2;
        }

        .btn-notify {
            background: #FF9800;
            color: white;
        }

        .btn-notify:hover {
            background: #F57C00;
        }

        .btn-clear-notifications {
            background: #9C27B0;
            color: white;
        }

        .btn-clear-notifications:hover {
            background: #7B1FA2;
        }

        .btn-delete {
            background: #f44336;
            color: white;
        }

        .btn-delete:hover {
            background: #d32f2f;
        }

        .program-info {
            font-size: 12px;
            color: #666;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .stats-summary {
                grid-template-columns: repeat(2, 1fr);
            }

            .filters-row {
                flex-direction: column;
                align-items: stretch;
            }

            .filter-group {
                width: 100%;
            }

            .table-container {
                font-size: 14px;
            }

            th, td {
                padding: 10px 8px;
            }

            .action-buttons {
                flex-direction: column;
            }
        }

        @media (max-width: 480px) {
            .stats-summary {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body class="dashboard-container admin-dashboard">
    <nav class="navbar">
        <div class="navbar-container">
            <a href="Administrador.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
                <span class="logo-text">Admin SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Administrador.php" class="nav-btn">📊 Dashboard</a>
                <a href="gestionar_aprendices.php" class="nav-btn active">👥 Aprendices</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="dashboard-content">
        <div class="aprendices-container">
            <?php if (isset($_GET['msg'])): ?>
                <?php if ($_GET['msg'] === 'eliminado'): ?>
                    <div class="alert alert-success" style="background:#d4edda; color:#155724; padding:15px; border-radius:5px; margin-bottom:20px;">
                        ✅ El aprendiz fue eliminado correctamente.
                    </div>
                <?php elseif ($_GET['msg'] === 'notificaciones_eliminadas'): ?>
                    <div class="alert alert-success" style="background:#d4edda; color:#155724; padding:15px; border-radius:5px; margin-bottom:20px;">
                        ✅ Las notificaciones fueron eliminadas correctamente.
                    </div>
                <?php elseif ($_GET['msg'] === 'error'): ?>
                    <div class="alert alert-danger" style="background:#f8d7da; color:#721c24; padding:15px; border-radius:5px; margin-bottom:20px;">
                        ❌ Hubo un error al procesar la solicitud.
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="welcome-section">
                <h1 class="welcome-title">Gestión de Aprendices</h1>
                <p class="welcome-subtitle">Administra y supervisa todos los aprendices registrados en el sistema.</p>
            </div>

            <!-- Estadísticas Resumidas -->
            <div class="stats-summary">
                <div class="summary-card">
                    <h3><?php echo $total_aprendices; ?></h3>
                    <p>Total Aprendices</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo $con_documentos; ?></h3>
                    <p>Con Documentos</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo $sin_documentos; ?></h3>
                    <p>Sin Documentos</p>
                </div>
            </div>

            <!-- Filtros de Búsqueda -->
            <div class="filters-section">
                <h3 style="margin-bottom: 15px; color: #2e7d32;">🔍 Filtros de Búsqueda</h3>
                <div class="filters-row">
                    <div class="filter-group">
                        <label for="searchName">Buscar por Nombre</label>
                        <input type="text" id="searchName" class="filter-input" placeholder="Nombre del aprendiz...">
                    </div>
                    <div class="filter-group">
                        <label for="searchEmail">Buscar por Correo</label>
                        <input type="text" id="searchEmail" class="filter-input" placeholder="Correo electrónico...">
                    </div>
                    <div class="filter-group">
                        <label for="filterStatus">Estado Documentos</label>
                        <select id="filterStatus" class="filter-input">
                            <option value="">Todos los estados</option>
                            <option value="Con documentos">Con documentos</option>
                            <option value="Sin documentos">Sin documentos</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="filterPrograma">Programa</label>
                        <select id="filterPrograma" class="filter-input">
                            <option value="">Todos los programas</option>
                            <?php while ($programa = $programas->fetch_assoc()): ?>
                                <option value="<?php echo strtolower($programa['nombre_programa']); ?>">
                                    <?php echo htmlspecialchars($programa['nombre_programa']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button onclick="clearFilters()" class="btn-filter">🗑️ Limpiar</button>
                </div>
            </div>

            <!-- Tabla de Aprendices -->
            <div class="aprendices-table">
                <div class="table-header">
                    <h2>📋 Lista de Aprendices Registrados</h2>
                    <span id="resultCount"><?php echo $total_aprendices; ?> aprendices encontrados</span>
                </div>

                <div class="table-container">
                    <?php if (!empty($aprendices)): ?>
                    <table id="aprendicesTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre Completo</th>
                                <th>Correo Electrónico</th>
                                <th>Programa de Formación</th>
                                <th>Fecha Registro</th>
                                <th>Estado Documentos</th>
                                <th>Notificaciones</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($aprendices as $aprendiz): ?>
                            <tr class="aprendiz-row" 
                                data-name="<?php echo strtolower($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?>"
                                data-email="<?php echo strtolower($aprendiz['Correo']); ?>"
                                data-status="<?php echo $aprendiz['estado_documentos']; ?>"
                                data-programa="<?php echo strtolower($aprendiz['nombre_programa'] ?? ''); ?>">
                                
                                <td><strong>#<?php echo $aprendiz['Id_registro']; ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($aprendiz['Correo']); ?></td>
                                <td>
                                    <?php if ($aprendiz['nombre_programa']): ?>
                                        <strong><?php echo htmlspecialchars($aprendiz['nombre_programa']); ?></strong>
                                        <div class="program-info">
                                            <?php echo htmlspecialchars($aprendiz['nivel_formacion'] . ' - ' . $aprendiz['jornada']); ?>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: #999;">No asignado</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($aprendiz['fecha_registro'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $aprendiz['estado_documentos'] === 'Con documentos' ? 'status-con-docs' : 'status-sin-docs'; ?>">
                                        <?php echo $aprendiz['estado_documentos']; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($aprendiz['notificaciones_pendientes'] > 0): ?>
                                        <span class="notification-badge"><?php echo $aprendiz['notificaciones_pendientes']; ?></span>
                                    <?php else: ?>
                                        <span style="color: #999;">Sin notificaciones</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="ver_aprendiz.php?id=<?php echo $aprendiz['Id_registro']; ?>" class="btn-action btn-view" title="Ver detalles">
                                            👁️ Ver
                                        </a>
                                        <a href="enviar_notificacion.php?id=<?php echo $aprendiz['Id_registro']; ?>" class="btn-action btn-notify" title="Enviar notificación">
                                            📧 Notificar
                                        </a>
                                        <?php if ($aprendiz['notificaciones_pendientes'] > 0): ?>
                                        <button class="btn-action btn-clear-notifications" title="Eliminar notificaciones" onclick="confirmarEliminacionNotificaciones(<?php echo $aprendiz['Id_registro']; ?>, '<?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?>', <?php echo $aprendiz['notificaciones_pendientes']; ?>)">
                                            🗑️ Limpiar
                                        </button>
                                        <?php endif; ?>
                                        <button class="btn-action btn-delete" title="Eliminar aprendiz" onclick="confirmarEliminacion(<?php echo $aprendiz['Id_registro']; ?>, '<?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?>')">
                                            🗑️ Eliminar
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: #666;">
                        <div style="font-size: 48px; margin-bottom: 20px;">👥</div>
                        <h3>No hay aprendices registrados</h3>
                        <p>Cuando se registren aprendices en el sistema, aparecerán aquí.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Funciones de filtrado en tiempo real
        function filterTable() {
            const nameFilter = document.getElementById('searchName').value.toLowerCase();
            const emailFilter = document.getElementById('searchEmail').value.toLowerCase();
            const statusFilter = document.getElementById('filterStatus').value;
            const programaFilter = document.getElementById('filterPrograma').value;

            const rows = document.querySelectorAll('.aprendiz-row');
            let visibleCount = 0;

            rows.forEach(row => {
                const name = row.dataset.name;
                const email = row.dataset.email;
                const status = row.dataset.status;
                const programa = row.dataset.programa;

                const nameMatch = name.includes(nameFilter);
                const emailMatch = email.includes(emailFilter);
                const statusMatch = statusFilter === '' || status === statusFilter;
                const programaMatch = programaFilter === '' || programa === programaFilter;

                if (nameMatch && emailMatch && statusMatch && programaMatch) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });

            document.getElementById('resultCount').textContent = `${visibleCount} aprendices encontrados`;
        }

        function clearFilters() {
            document.getElementById('searchName').value = '';
            document.getElementById('searchEmail').value = '';
            document.getElementById('filterStatus').value = '';
            document.getElementById('filterPrograma').value = '';
            filterTable();
        }

        // Event listeners para filtrado en tiempo real
        document.getElementById('searchName').addEventListener('input', filterTable);
        document.getElementById('searchEmail').addEventListener('input', filterTable);
        document.getElementById('filterStatus').addEventListener('change', filterTable);
        document.getElementById('filterPrograma').addEventListener('change', filterTable);

        // Función para confirmar eliminación de aprendiz
        function confirmarEliminacion(id, nombre) {
            if (confirm(`¿Estás seguro de que deseas eliminar el aprendiz "${nombre}"?\n\nEsta acción no se puede deshacer y eliminará todos sus documentos y notificaciones.`)) {
                window.location.href = `eliminar_aprendiz.php?id=${id}`;
            }
        }

        // Función para confirmar eliminación de notificaciones
        function confirmarEliminacionNotificaciones(id, nombre, cantidadNotificaciones) {
            if (confirm(`¿Estás seguro de que deseas eliminar las ${cantidadNotificaciones} notificaciones pendientes de "${nombre}"?\n\nEsta acción no se puede deshacer.`)) {
                window.location.href = `eliminar_notificaciones.php?id=${id}`;
            }
        }

        // Efecto de carga suave
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.summary-card, .filters-section, .aprendices-table');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>
