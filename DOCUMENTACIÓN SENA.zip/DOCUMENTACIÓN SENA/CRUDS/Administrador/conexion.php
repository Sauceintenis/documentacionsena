<?php
$servidor = "localhost";
$usuario_db = "root";
$contraseña_db = "";
$base_datos = "documentacion_sena";

try {
    $conexion = new PDO("mysql:host=$servidor;dbname=$base_datos;charset=utf8", $usuario_db, $contraseña_db);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    
    error_log("Error de conexión a la base de datos: " . $e->getMessage());
    die("Error de conexión. Por favor, intente más tarde.");
}
?>
