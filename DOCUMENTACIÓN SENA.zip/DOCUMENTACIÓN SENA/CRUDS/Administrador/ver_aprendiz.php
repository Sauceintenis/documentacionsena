<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
// Verificar que sea administrador
if ($_SESSION['Rol'] != 2) { 
    header('Location: ../../index.php'); 
    exit(); 
}

require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

// Validar ID recibido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: gestionar_aprendices.php");
    exit();
}

$id_aprendiz = intval($_GET['id']);

// Obtener información completa del aprendiz (SIN duracion_meses)
$query = "SELECT 
    r.*,
    p.nombre_programa,
    p.nivel_formacion,
    p.jornada,
    CASE 
        WHEN a.usuario_id IS NOT NULL THEN 'Con documentos'
        ELSE 'Sin documentos'
    END as estado_documentos
FROM registro r
LEFT JOIN programas_formacion p ON r.programa_id = p.id
LEFT JOIN aprendiz_sena a ON r.Id_registro = a.usuario_id
WHERE r.Id_registro = ? AND r.Rol = 1";

$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_aprendiz);
$stmt->execute();
$aprendiz = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$aprendiz) {
    header("Location: gestionar_aprendices.php?msg=error");
    exit();
}

// Obtener notificaciones del aprendiz
$stmt_notif = $conexion->prepare("
    SELECT n.*, r.Nombre as admin_nombre, r.Apellidos as admin_apellidos 
    FROM notificaciones n
    LEFT JOIN registro r ON n.enviada_por = r.Id_registro
    WHERE n.usuario_id = ? 
    ORDER BY n.fecha_creacion DESC
");
$stmt_notif->bind_param("i", $id_aprendiz);
$stmt_notif->execute();
$notificaciones = $stmt_notif->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_notif->close();

// Obtener documentos si existen
$stmt_docs = $conexion->prepare("SELECT * FROM aprendiz_sena WHERE usuario_id = ?");
$stmt_docs->bind_param("i", $id_aprendiz);
$stmt_docs->execute();
$documentos = $stmt_docs->get_result()->fetch_assoc();
$stmt_docs->close();

// Obtener documentos de encadenamiento si existen
$stmt_enc = $conexion->prepare("SELECT * FROM encadenamiento_sena WHERE usuario_id = ?");
$stmt_enc->bind_param("i", $id_aprendiz);
$stmt_enc->execute();
$encadenamiento = $stmt_enc->get_result()->fetch_assoc();
$stmt_enc->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Aprendiz - <?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?></title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
    <style>
        .aprendiz-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .aprendiz-header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }

        .aprendiz-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(45deg, #4caf50, #81c784);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 36px;
            font-weight: bold;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }

        .info-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .info-card h3 {
            color: #2e7d32;
            margin-bottom: 20px;
            font-size: 18px;
            border-bottom: 2px solid #e8f5e9;
            padding-bottom: 10px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 600;
            color: #555;
        }

        .info-value {
            color: #333;
            font-weight: 500;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status-con-docs {
            background: #d4edda;
            color: #155724;
        }

        .status-sin-docs {
            background: #fff3cd;
            color: #856404;
        }

        .notifications-section {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .notification-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #ff9800;
        }

        .notification-item:last-child {
            margin-bottom: 0;
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .notification-type {
            background: #ff9800;
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .notification-date {
            color: #666;
            font-size: 12px;
        }

        .notification-message {
            color: #333;
            line-height: 1.5;
        }

        .notification-admin {
            color: #666;
            font-size: 12px;
            font-style: italic;
            margin-top: 8px;
        }

        .documents-section {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .document-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .document-item:last-child {
            border-bottom: none;
        }

        .document-status {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .doc-uploaded {
            background: #d4edda;
            color: #155724;
        }

        .doc-pending {
            background: #fff3cd;
            color: #856404;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }

        .btn-action {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: #4caf50;
            color: white;
        }

        .btn-primary:hover {
            background: #45a049;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }
    </style>
</head>
<body class="dashboard-container admin-dashboard">
    <nav class="navbar">
        <div class="navbar-container">
            <a href="Administrador.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
                <span class="logo-text">Admin SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Administrador.php" class="nav-btn">📊 Dashboard</a>
                <a href="gestionar_aprendices.php" class="nav-btn">👥 Aprendices</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="dashboard-content">
        <div class="aprendiz-container">
            <div class="aprendiz-header">
                <div class="aprendiz-avatar">
                    <?php echo strtoupper(substr($aprendiz['Nombre'], 0, 1) . substr($aprendiz['Apellidos'], 0, 1)); ?>
                </div>
                <h1><?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?></h1>
                <p style="color: #666; font-size: 16px;">Aprendiz SENA - ID: #<?php echo $aprendiz['Id_registro']; ?></p>
                <span class="status-badge <?php echo $aprendiz['estado_documentos'] === 'Con documentos' ? 'status-con-docs' : 'status-sin-docs'; ?>">
                    <?php echo $aprendiz['estado_documentos']; ?>
                </span>
            </div>

            <div class="info-grid">
                <div class="info-card">
                    <h3>📋 Información Personal</h3>
                    <div class="info-item">
                        <span class="info-label">Nombre Completo:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Tipo de Documento:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['tipo_documento']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Número de Documento:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['numero_documento']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Correo Electrónico:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['Correo']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Fecha de Registro:</span>
                        <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($aprendiz['fecha_registro'])); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Es Menor de Edad:</span>
                        <span class="info-value"><?php echo $aprendiz['es_menor_edad'] === 'si' ? 'Sí' : 'No'; ?></span>
                    </div>
                </div>

                <div class="info-card">
                    <h3>🎓 Programa de Formación</h3>
                    <?php if ($aprendiz['nombre_programa']): ?>
                        <div class="info-item">
                            <span class="info-label">Programa:</span>
                            <span class="info-value"><?php echo htmlspecialchars($aprendiz['nombre_programa']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Nivel:</span>
                            <span class="info-value"><?php echo htmlspecialchars($aprendiz['nivel_formacion']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Jornada:</span>
                            <span class="info-value"><?php echo htmlspecialchars($aprendiz['jornada']); ?></span>
                        </div>
                    <?php else: ?>
                        <p style="color: #999; text-align: center; padding: 20px;">No tiene programa asignado</p>
                    <?php endif; ?>
                </div>

                <?php if ($aprendiz['es_menor_edad'] === 'si'): ?>
                <div class="info-card">
                    <h3>👨‍👩‍👧‍👦 Representante Legal</h3>
                    <div class="info-item">
                        <span class="info-label">Nombre:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['nombre_completo_representante'] ?? 'No especificado'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Tipo de Documento:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['tipo_documento_representante'] ?? 'No especificado'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Número de Documento:</span>
                        <span class="info-value"><?php echo htmlspecialchars($aprendiz['numero_documento_representante'] ?? 'No especificado'); ?></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sección de Notificaciones -->
            <div class="notifications-section">
                <h3 style="color: #2e7d32; margin-bottom: 20px;">🔔 Notificaciones (<?php echo count($notificaciones); ?>)</h3>
                <?php if (!empty($notificaciones)): ?>
                    <?php foreach ($notificaciones as $notif): ?>
                        <div class="notification-item">
                            <div class="notification-header">
                                <span class="notification-type"><?php echo htmlspecialchars($notif['tipo_notificacion']); ?></span>
                                <span class="notification-date"><?php echo date('d/m/Y H:i', strtotime($notif['fecha_creacion'])); ?></span>
                            </div>
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['mensaje']); ?>
                            </div>
                            <div class="notification-admin">
                                Enviado por: <?php echo htmlspecialchars(($notif['admin_nombre'] ?? 'Sistema') . ' ' . ($notif['admin_apellidos'] ?? '')); ?>
                                <?php if ($notif['leida']): ?>
                                    <span style="color: #4caf50;">• Leída</span>
                                <?php else: ?>
                                    <span style="color: #ff9800;">• Pendiente</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <?php if (count(array_filter($notificaciones, fn($n) => !$n['leida'])) > 0): ?>
                        <div style="text-align: center; margin-top: 20px;">
                            <button onclick="confirmarEliminacionNotificaciones()" class="btn-action btn-warning">
                                🗑️ Eliminar Todas las Notificaciones
                            </button>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p style="color: #999; text-align: center; padding: 20px;">No tiene notificaciones</p>
                <?php endif; ?>
            </div>

            <!-- Sección de Documentos Regulares -->
            <div class="documents-section">
                <h3 style="color: #2e7d32; margin-bottom: 20px;">📄 Documentos Regulares</h3>
                <?php if ($documentos): ?>
                    <div class="document-item">
                        <span>Documento de Identidad</span>
                        <span class="document-status <?php echo !empty($documentos['Tarjeta_Identidad']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($documentos['Tarjeta_Identidad']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Registro Civil</span>
                        <span class="document-status <?php echo !empty($documentos['Registro_civil']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($documentos['Registro_civil']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Certificado EPS</span>
                        <span class="document-status <?php echo !empty($documentos['EPS']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($documentos['EPS']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Firma del Aprendiz</span>
                        <span class="document-status <?php echo !empty($documentos['Firma_Aprendiz']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($documentos['Firma_Aprendiz']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <?php if ($aprendiz['es_menor_edad'] === 'si'): ?>
                    <div class="document-item">
                        <span>Firma del Tutor</span>
                        <span class="document-status <?php echo !empty($documentos['Firma_Tutor']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($documentos['Firma_Tutor']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p style="color: #999; text-align: center; padding: 20px;">No ha subido documentos regulares</p>
                <?php endif; ?>
            </div>

            <!-- Sección de Documentos de Encadenamiento -->
            <div class="documents-section">
                <h3 style="color: #2e7d32; margin-bottom: 20px;">⛓️ Documentos de Encadenamiento</h3>
                <?php if ($encadenamiento): ?>
                    <div class="document-item">
                        <span>Acta de Grados</span>
                        <span class="document-status <?php echo !empty($encadenamiento['Acta_Grados']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($encadenamiento['Acta_Grados']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Resultado ICFES</span>
                        <span class="document-status <?php echo !empty($encadenamiento['Resultado_ICFES']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($encadenamiento['Resultado_ICFES']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Actualizar EPS</span>
                        <span class="document-status <?php echo !empty($encadenamiento['Actualizar_EPS']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($encadenamiento['Actualizar_EPS']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <div class="document-item">
                        <span>Documento de Identidad</span>
                        <span class="document-status <?php echo !empty($encadenamiento['Documento_Identidad']) ? 'doc-uploaded' : 'doc-pending'; ?>">
                            <?php echo !empty($encadenamiento['Documento_Identidad']) ? 'Cargado' : 'Pendiente'; ?>
                        </span>
                    </div>
                    <p style="color: #666; font-size: 12px; margin-top: 15px;">
                        <strong>Fecha de subida:</strong> <?php echo date('d/m/Y H:i', strtotime($encadenamiento['fecha_subida'])); ?>
                    </p>
                <?php else: ?>
                    <p style="color: #999; text-align: center; padding: 20px;">No ha subido documentos de encadenamiento</p>
                <?php endif; ?>
            </div>

            <div class="action-buttons">
                <a href="gestionar_aprendices.php" class="btn-action btn-secondary">← Volver a la Lista</a>
                <a href="enviar_notificacion.php?id=<?php echo $aprendiz['Id_registro']; ?>" class="btn-action btn-warning">📧 Enviar Notificación</a>
                <?php if ($documentos): ?>
                    <a href="ver_documentos_aprendiz.php?id=<?php echo $aprendiz['Id_registro']; ?>" class="btn-action btn-primary">👁️ Ver Documentos</a>
                <?php endif; ?>
            </div>
            <div class="jostin"></div>
        </div>
    </div>

    <script>
        function confirmarEliminacionNotificaciones() {
            if (confirm('¿Estás seguro de que deseas eliminar todas las notificaciones de este aprendiz?\n\nEsta acción no se puede deshacer.')) {
                window.location.href = `eliminar_notificaciones.php?id=<?php echo $aprendiz['Id_registro']; ?>`;
            }
        }
    </script>
</body>
</html>
