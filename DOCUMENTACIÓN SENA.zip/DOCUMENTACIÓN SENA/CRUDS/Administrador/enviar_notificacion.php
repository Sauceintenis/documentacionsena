<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

// ⚠️ IMPORTANTE: Usar PHPMailer en lugar de mail() nativo
require_once __DIR__ . '/../../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../../PHPMailer/src/SMTP.php';
require_once __DIR__ . '/../../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Verificar que sea administrador
if ($_SESSION['Rol'] != 2) { 
    header('Location: ../../index.php'); 
    exit(); 
}

// Validar ID recibido
if (!isset($_GET['id'])) {
    header("Location: gestionar_aprendices.php");
    exit();
}

$id_aprendiz = intval($_GET['id']);

// Obtener datos del aprendiz
$stmt = $conexion->prepare("SELECT Nombre, Apellidos, Correo FROM registro WHERE Id_registro = ?");
$stmt->bind_param("i", $id_aprendiz);
$stmt->execute();
$aprendiz = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$aprendiz) {
    die("❌ Error: Aprendiz no encontrado.");
}

// Función para enviar notificación usando PHPMailer
function enviarNotificacionPHPMailer($correo_destino, $nombre_completo) {
    $mail = new PHPMailer(true);

    try {
        // ✅ CONFIGURACIÓN SMTP CON TUS CREDENCIALES
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'sistemadocumentacionsena@gmail.com';  // ✅ Tu correo
        $mail->Password   = 'mupn bxwb napb lksy';                 // ✅ Tu contraseña de aplicación
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Configuración del correo
        $mail->setFrom('sistemadocumentacionsena@gmail.com', 'Administración SENA'); // ✅ Tu correo
        $mail->addAddress($correo_destino, $nombre_completo);

        // Contenido del correo
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = '📋 Recordatorio: Documentos Pendientes - SENA';
        
        $mail->Body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(135deg, #ff9800, #ffb74d); color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; }
                .alert-box { background: #fff3e0; border-left: 4px solid #ff9800; padding: 20px; margin: 20px 0; border-radius: 8px; }
                .footer { background: #2e7d32; color: white; padding: 20px; text-align: center; font-size: 14px; }
                .btn { display: inline-block; background: #4caf50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>⚠️ Recordatorio SENA</h1>
                    <p>Documentos Pendientes de Carga</p>
                </div>
                
                <div class='content'>
                    <p>Estimado(a) <strong>$nombre_completo</strong>,</p>
                    
                    <div class='alert-box'>
                        <h3>📋 Acción Requerida</h3>
                        <p>Este es un recordatorio de que <strong>debe completar la carga de documentos requeridos</strong> en la plataforma del SENA.</p>
                    </div>
                    
                    <h3>📝 Pasos a seguir:</h3>
                    <ol>
                        <li>Ingrese al sistema con su número de documento</li>
                        <li>Vaya a la sección \"Mis Documentos\"</li>
                        <li>Complete la carga de todos los documentos pendientes</li>
                        <li>Verifique que todos los documentos estén en estado \"Cargado\"</li>
                    </ol>
                    
                    <div style='text-align: center; margin: 30px 0;'>
                        <a href='http://localhost/DOCUMENTACIÓN%20SENA/index.php' class='btn'>🚀 Acceder al Sistema</a>
                    </div>
                    
                    <p><strong>Importante:</strong> La carga completa de documentos es obligatoria para continuar con su proceso de formación en el SENA.</p>
                </div>
                
                <div class='footer'>
                    <p><strong>Administración SENA</strong></p>
                    <p>Sistema de Documentación Digital</p>
                    <p>Este es un correo automático, por favor no responder.</p>
                </div>
            </div>
        </body>
        </html>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Error al enviar notificación: {$mail->ErrorInfo}");
        return false;
    }
}

// Enviar la notificación
$nombre_completo = $aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos'];
if (enviarNotificacionPHPMailer($aprendiz['Correo'], $nombre_completo)) {
    // Registrar la notificación en la base de datos
    $admin_id = $_SESSION['Id_registro'];
    $tipo_notificacion = 'subir_documentos';
    $mensaje = "Recordatorio: Debe completar la carga de documentos requeridos en el sistema SENA.";
    
    $stmt = $conexion->prepare("INSERT INTO notificaciones (usuario_id, tipo_notificacion, mensaje, enviada_por) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issi", $id_aprendiz, $tipo_notificacion, $mensaje, $admin_id);
    $stmt->execute();
    $stmt->close();
    
    echo "<script>alert('✅ Correo enviado exitosamente a {$aprendiz['Correo']}'); window.location.href='gestionar_aprendices.php';</script>";
} else {
    echo "<script>alert('❌ Error al enviar el correo. Revise la configuración SMTP.'); window.location.href='gestionar_aprendices.php';</script>";
}

$conexion->close();
?>
