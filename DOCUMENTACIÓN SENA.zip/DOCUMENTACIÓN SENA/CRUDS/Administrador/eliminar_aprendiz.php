<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';

// Verificar que sea administrador
if ($_SESSION['Rol'] != 2) { 
    header('Location: ../../index.php'); 
    exit(); 
}

require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

if (isset($_GET['id'])) {
    $id_aprendiz = intval($_GET['id']);

    // Eliminar notificaciones relacionadas
    $stmt = $conexion->prepare("DELETE FROM notificaciones WHERE usuario_id = ?");
    $stmt->bind_param("i", $id_aprendiz);
    $stmt->execute();

    // Eliminar documentos relacionados en aprendiz_sena
    $stmt = $conexion->prepare("DELETE FROM aprendiz_sena WHERE usuario_id = ?");
    $stmt->bind_param("i", $id_aprendiz);
    $stmt->execute();

    // Finalmente, eliminar al aprendiz del registro
    $stmt = $conexion->prepare("DELETE FROM registro WHERE Id_registro = ?");
    $stmt->bind_param("i", $id_aprendiz);
    $stmt->execute();

    // Redirigir de nuevo con mensaje
    header("Location: gestionar_aprendices.php?msg=eliminado");
    exit();
} else {
    header("Location: gestionar_aprendices.php?msg=error");
    exit();
}
?>
