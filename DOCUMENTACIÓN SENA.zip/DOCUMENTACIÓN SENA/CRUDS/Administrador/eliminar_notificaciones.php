<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';

// Verificar que sea administrador
if ($_SESSION['Rol'] != 2) { 
    header('Location: ../../index.php'); 
    exit(); 
}

require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

// Validar que se recibió un ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: gestionar_aprendices.php?msg=error");
    exit();
}

$id_aprendiz = intval($_GET['id']);

// Verificar que el aprendiz existe
$stmt_verificar = $conexion->prepare("SELECT Nombre, Apellidos FROM registro WHERE Id_registro = ? AND Rol = 1");
$stmt_verificar->bind_param("i", $id_aprendiz);
$stmt_verificar->execute();
$aprendiz = $stmt_verificar->get_result()->fetch_assoc();
$stmt_verificar->close();

if (!$aprendiz) {
    header("Location: gestionar_aprendices.php?msg=error");
    exit();
}

// Contar las notificaciones antes de eliminar (para logging)
$stmt_contar = $conexion->prepare("SELECT COUNT(*) as total FROM notificaciones WHERE usuario_id = ?");
$stmt_contar->bind_param("i", $id_aprendiz);
$stmt_contar->execute();
$resultado_contar = $stmt_contar->get_result()->fetch_assoc();
$total_notificaciones = $resultado_contar['total'];
$stmt_contar->close();

// Eliminar todas las notificaciones del aprendiz
$stmt_eliminar = $conexion->prepare("DELETE FROM notificaciones WHERE usuario_id = ?");
$stmt_eliminar->bind_param("i", $id_aprendiz);

if ($stmt_eliminar->execute()) {
    $notificaciones_eliminadas = $stmt_eliminar->affected_rows;
    $stmt_eliminar->close();
    
    // Log de la acción (opcional - para auditoría)
    $admin_nombre = $_SESSION['Nombre'] . ' ' . $_SESSION['Apellidos'];
    $aprendiz_nombre = $aprendiz['Nombre'] . ' ' . $aprendiz['Apellidos'];
    $fecha_accion = date('Y-m-d H:i:s');
    
    error_log("ADMIN ACTION: {$admin_nombre} eliminó {$notificaciones_eliminadas} notificaciones de {$aprendiz_nombre} el {$fecha_accion}");
    
    // Redirigir con mensaje de éxito
    header("Location: gestionar_aprendices.php?msg=notificaciones_eliminadas");
} else {
    // Error al eliminar
    $stmt_eliminar->close();
    header("Location: gestionar_aprendices.php?msg=error");
}

$conexion->close();
exit();
?>
