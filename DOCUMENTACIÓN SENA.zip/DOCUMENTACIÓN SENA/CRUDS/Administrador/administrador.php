<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';

require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

// Obtener estadísticas generales
$total_aprendices = $conexion->query("SELECT COUNT(*) FROM registro WHERE Rol = 1")->fetch_row()[0];
$aprendices_con_documentos = $conexion->query("SELECT COUNT(DISTINCT usuario_id) FROM aprendiz_sena")->fetch_row()[0];
$aprendices_sin_documentos = $total_aprendices - $aprendices_con_documentos;
$total_notificaciones = $conexion->query("SELECT COUNT(*) FROM notificaciones WHERE leida = 0")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador - SENA</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container admin-dashboard">
    <nav class="navbar">
        <div class="navbar-container">
            <a href="Administrador.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/logo.png" alt="SENA Logo"></div>
                <span class="logo-text">Admin SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Administrador.php" class="nav-btn active">📊 Dashboard</a>
                <a href="gestionar_aprendices.php" class="nav-btn">👥 Aprendices</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="dashboard-content">
        <div class="welcome-section">
            <h1 class="welcome-title">Panel de Administrador</h1>
            <p class="welcome-subtitle">Supervisión y gestión del sistema de documentación.</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card stat-primary">
                <div class="stat-icon">👥</div>
                <div class="stat-content">
                    <h3><?php echo $total_aprendices; ?></h3>
                    <p>Total Aprendices</p>
                </div>
            </div>
            <div class="stat-card stat-success">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <h3><?php echo $aprendices_con_documentos; ?></h3>
                    <p>Con Documentos</p>
                </div>
            </div>
            <div class="stat-card stat-warning">
                <div class="stat-icon">⚠️</div>
                <div class="stat-content">
                    <h3><?php echo $aprendices_sin_documentos; ?></h3>
                    <p>Sin Documentos</p>
                </div>
            </div>
        </div>

        <div class="admin-actions">
            <div class="action-card">
                <h3>Gestionar Aprendices</h3>
                <p>Ver, supervisar y enviar notificaciones a los aprendices registrados.</p>
                <a href="gestionar_aprendices.php" class="btn-action">Acceder</a>
            </div>
             <div class="action-card">
                <h3>Ayuda y Soporte</h3>
                <p>Generar reportes detallados sobre el estado de la documentación.</p>
                <a href="https://portal.senasofiaplus.edu.co/" class="btn-action">Navegar</a>
            </div>
        </div>
    </div>
</body>
</html>
