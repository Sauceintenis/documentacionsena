<?php
session_start();
if(!isset($_SESSION['Usuario']) || $_SESSION['Rol'] != 2) {
    header("location: ../../index.php");
    exit();
}

include 'conexion.php';

$aprendiz_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$aprendiz_id) {
    header("location: gestionar_aprendices.php");
    exit();
}

$stmt = $conexion->prepare("
    SELECT r.Nombre, r.Apellidos, a.*
    FROM registro r
    JOIN aprendiz_sena a ON r.Id_registro = a.usuario_id
    WHERE r.Id_registro = ?
");
$stmt->execute([$aprendiz_id]);
$documentos = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$documentos) {
    echo "No se encontraron documentos para este aprendiz o el aprendiz no existe.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentos de <?php echo htmlspecialchars($documentos['Nombre']); ?></title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container">
    <div class="document-container fade-in">
        <h1>Documentos de <?php echo htmlspecialchars($documentos['Nombre'] . ' ' . $documentos['Apellidos']); ?></h1>
        <a href="gestionar_aprendices.php" class="btn-back">← Volver</a>
        <div class="document-details">
            <h3>Documentos Cargados</h3>
            <ul>
                <li><strong>EPS Seleccionada:</strong> <?php echo htmlspecialchars($documentos['eps_seleccionada']); ?></li>
                <li><a href="../../<?php echo htmlspecialchars($documentos['Registro_civil']); ?>" target="_blank">Ver Registro Civil</a></li>
                <li><a href="../../<?php echo htmlspecialchars($documentos['Tarjeta_Identidad']); ?>" target="_blank">Ver Tarjeta de Identidad</a></li>
                <li><a href="../../<?php echo htmlspecialchars($documentos['EPS']); ?>" target="_blank">Ver Archivo EPS</a></li>
                <li><a href="../Aprendiz/ver_compromiso_completo.php?id=<?php echo $documentos['Id']; ?>" target="_blank">Ver Compromiso del Aprendiz</a></li>
                <li><a href="../Aprendiz/ver_documento_completo.php?id=<?php echo $documentos['Id']; ?>" target="_blank">Ver Tratamiento de Datos</a></li>
            </ul>
        </div>
    </div>
</body>
</html>
