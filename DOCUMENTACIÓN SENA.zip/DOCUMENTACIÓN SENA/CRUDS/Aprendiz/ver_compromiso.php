<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$id_documento = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id_documento) {
    die("ID de documento no válido.");
}

// Consulta para obtener todos los datos necesarios
$stmt = $conexion->prepare("
    SELECT 
        r.Nombre AS nombre_aprendiz,
        r.Apellidos AS apellidos_aprendiz,
        r.tipo_documento,
        r.numero_documento AS doc_aprendiz,
        r.es_menor_edad,
        r.nombre_completo_representante,
        r.tipo_documento_representante,
        r.numero_documento_representante,
        a.Firma_Aprendiz,
        a.Firma_Tutor
    FROM aprendiz_sena a
    JOIN registro r ON a.usuario_id = r.Id_registro
    WHERE a.Id = ?
");
$stmt->bind_param("i", $id_documento);
$stmt->execute();
$datos = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conexion->close();

if (!$datos) {
    die("No se encontraron datos para este documento.");
}

$nombre_completo_aprendiz = htmlspecialchars($datos['nombre_aprendiz'] . ' ' . $datos['apellidos_aprendiz']);
$es_ti = ($datos['tipo_documento'] === 'TI') ? 'X' : '&nbsp;';
$es_cc = ($datos['tipo_documento'] === 'CC') ? 'X' : '&nbsp;';
$es_ce = ($datos['tipo_documento'] === 'CE') ? 'X' : '&nbsp;';
$es_otro = !in_array($datos['tipo_documento'], ['TI', 'CC', 'CE']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formato Compromiso del Aprendiz</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body { font-family: 'Helvetica', 'Arial', sans-serif; font-size: 10pt; line-height: 1.4; color: #333; }
        .container { max-width: 800px; margin: 20px auto; padding: 30px; border: 1px solid #ccc; background: #fff; }
        .header { text-align: center; margin-bottom: 25px; font-weight: bold; }
        .header p { margin: 2px 0; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; vertical-align: bottom; }
        .content { text-align: justify; }
        .content ol { padding-left: 20px; }
        .content li { margin-bottom: 8px; }
        .firma-area { margin-top: 25px; }
        .firma-block { margin-top: 20px; }
        .firma-img { max-height: 50px; max-width: 180px; display: block; margin-bottom: 5px; }
        .form-line { border-bottom: 1px solid #000; padding: 0 5px; font-weight: bold; }
        .checkbox { display: inline-block; width: 18px; height: 18px; border: 1px solid #000; text-align: center; line-height: 18px; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" class="btn-document secondary">Imprimir</button>
        <a href="index_Aprendiz.php" class="btn-document secondary">Volver</a>
    </div>
    <div class="container" id="document-to-print">
        <div class="header">
            <p>PROCESO GESTIÓN DE FORMACIÓN PROFESIONAL INTEGRAL</p>
            <p>FORMATO “MI COMPROMISO COMO APRENDIZ SENA”</p>
            <p>GFPI-F-015 V.3</p>
        </div>
        
        <table class="info-table">
            <tr>
                <td style="width: 3%;">Yo,</td>
                <td style="border-bottom: 1px solid #000; text-align: center; font-weight: bold;"><?php echo $nombre_completo_aprendiz; ?></td>
            </tr>
        </table>

        <table class="info-table">
            <tr>
                <td style="width: 20%;">Con documento de identidad:</td>
                <td style="width: 20%;"><span class="checkbox"><?php echo $es_ti; ?></span> Tarjeta de Identidad</td>
                <td style="width: 20%;"><span class="checkbox"><?php echo $es_cc; ?></span> Cédula de Ciudadanía</td>
                <td style="width: 20%;"><span class="checkbox"><?php echo $es_ce; ?></span> Cédula de Extranjería</td>
            </tr>
            <tr>
                <td>No. <span class="form-line"><?php echo htmlspecialchars($datos['doc_aprendiz']); ?></span></td>
                <td colspan="3">Otro <span class="checkbox"><?php echo $es_otro ? 'X' : '&nbsp;'; ?></span> Cual <span class="form-line"><?php echo $es_otro ? htmlspecialchars($datos['tipo_documento']) : '_________________'; ?></span></td>
            </tr>
        </table>

        <table class="info-table">
            <tr>
                <td>Matriculado en el programa de formación:</td>
                <td style="border-bottom: 1px solid #000; text-align: center; font-weight: bold;">Técnico en Programación de Software</td>
            </tr>
             <tr>
                <td>Ficha de Caracterización No. <span class="form-line">2024001</span></td>
                <td>Del Centro de Formación: <span class="form-line">Centro de Servicios y Gestión Empresarial</span></td>
            </tr>
        </table>

        <div class="content">
            <p>Me comprometo con el Servicio Nacional de Aprendizaje - SENA, en mi calidad de Aprendiz, y como persona responsable de mis actos, a:</p>
            <ol>
                <li>Cumplir y promover las disposiciones contempladas en el Reglamento del Aprendiz SENA...</li>
                <li>Participar en todo el proceso de inducción para iniciar el programa de formación...</li>
                <li>Portar en todo momento el carné de identificación institucional en sitio visible.</li>
                <li>Proyectar la imagen corporativa del Sena dentro y fuera de la Entidad...</li>
                <li>Respetar la orientación sexual, identidad de género, edad, etnia, culto, religión...</li>
                <li>Al finalizar la formación dar cumplimiento oportuno a todos los trámites académicos...</li>
                <li>Si soy seleccionado como beneficiario para recibir apoyo de sostenimiento...</li>
                <li>Registrar y mantener actualizados mis datos personales y de contacto...</li>
                <li>Con la firma del presente compromiso autorizo al Sena para que me notifique a través de mi correo electrónico...</li>
            </ol>
        </div>

        <div class="firma-area">
            <div class="firma-block">
                <?php if (!empty($datos['Firma_Aprendiz']) && file_exists(__DIR__ . '/../../' . $datos['Firma_Aprendiz'])): ?>
                    <img src="../../<?php echo htmlspecialchars($datos['Firma_Aprendiz']); ?>" alt="Firma del Aprendiz" class="firma-img">
                <?php else: ?>
                    <div style="height: 50px; text-align: center; color: #999;">Firma no disponible</div>
                <?php endif; ?>
                <div style="border-top: 1px solid #000; padding-top: 5px;">
                    <strong>FIRMA DEL APRENDIZ:</strong><br>
                    No. Documento de Identidad: <span class="form-line"><?php echo htmlspecialchars($datos['doc_aprendiz']); ?></span>
                </div>
            </div>

            <?php if ($datos['es_menor_edad'] === 'si'): ?>
            <div class="firma-block">
                <?php if (!empty($datos['Firma_Tutor']) && file_exists(__DIR__ . '/../../' . $datos['Firma_Tutor'])): ?>
                    <img src="../../<?php echo htmlspecialchars($datos['Firma_Tutor']); ?>" alt="Firma del Tutor" class="firma-img">
                <?php else: ?>
                    <div style="height: 50px; text-align: center; color: #999;">Firma no disponible</div>
                <?php endif; ?>
                <div style="border-top: 1px solid #000; padding-top: 5px;">
                    <strong>FIRMA DE: LA MADRE, EL PADRE O TUTOR (A)</strong><br>
                    <small>(Únicamente en caso de que el (la) aprendiz sea menor de edad...)</small><br>
                    Tipo y No. Documento de Identidad: <span class="form-line"><?php echo htmlspecialchars($datos['tipo_documento_representante'] . ' ' . $datos['numero_documento_representante']); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <table class="info-table" style="margin-top: 25px;">
                <tr>
                    <td>FECHA DE DILIGENCIAMIENTO:</td>
                    <td>DIA: <span class="form-line"><?php echo date('d'); ?></span></td>
                    <td>MES: <span class="form-line"><?php echo date('m'); ?></span></td>
                    <td>AÑO: <span class="form-line"><?php echo date('Y'); ?></span></td>
                </tr>
            </table>
        </div>
        <p style="font-size: 8pt; text-align: center; margin-top: 20px;">
            Este documento forma parte de la ficha académica del aprendiz y es prueba del compromiso que adquiere con el SENA de cumplir el Reglamento de Aprendices SENA...
        </p>
    </div>

    <script>
        document.getElementById('download-pdf-btn').addEventListener('click', function () {
            const element = document.getElementById('document-to-print');
            const opt = {
                margin:       0.5,
                filename:     'Compromiso-Aprendiz-SENA.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            
            html2pdf().from(element).set(opt).save();
        });
    </script>
</body>
</html>
