<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$id_usuario = $_SESSION['Id_registro'];

// Consulta para obtener los documentos de encadenamiento del usuario
$stmt = $conexion->prepare("
SELECT r.es_menor_edad, e.* 
FROM registro r
LEFT JOIN encadenamiento_sena e ON r.Id_registro = e.usuario_id
WHERE r.Id_registro = ?
");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$datos_usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();

$es_menor = ($datos_usuario['es_menor_edad'] === 'si');
$tiene_documentos = !empty($datos_usuario['id']); // id en encadenamiento_sena

// Función para mostrar el estado de cada documento
function render_document_row($label, $file_path) {
    $root_path = __DIR__ . '/../../'; // Ruta física del proyecto
    $html = "<tr><td>{$label}</td>";

    if (!empty($file_path) && file_exists($root_path . $file_path)) {
        // Documento cargado
        $html .= '<td><span class="btn-sm btn-success">Cargado</span></td>';
        $html .= '<td><a href="../../' . htmlspecialchars($file_path) . '" target="_blank" class="btn-sm btn-info">Ver</a></td>';
    } else {
        // Documento pendiente
        $html .= '<td><span class="btn-sm btn-danger">Pendiente</span></td>';
        $html .= '<td><span class="text-muted">No disponible</span></td>';
    }

    $html .= "</tr>";
    return $html;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Encadenamiento - SENA</title>
<link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container">

<!-- Barra de navegación -->
<nav class="navbar">
    <div class="navbar-container">
        <a href="Aprendiz.php" class="navbar-logo">
            <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
            <span class="logo-text">SENA</span>
        </a>
        <div class="navbar-menu">
            <a href="Aprendiz.php" class="nav-btn">🏠 Inicio</a>
            <a href="index_Aprendiz.php" class="nav-btn">📄 Mis Documentos</a>
            <a href="index_encadenar.php" class="nav-btn active">⛓︎ Encadenamiento</a>
            <a href="perfil.php" class="nav-btn">👤 Mi Perfil</a>
            <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
        </div>
    </div>
</nav>

<div class="dashboard-content">
    <div class="welcome-section">
        <h1 class="welcome-title">Gestión de Documentos de Encadenamiento</h1>
        <p class="welcome-subtitle">Sube y administra tus documentos requeridos.</p>
    </div>

    <!-- Mensajes de estado -->
    <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
        <div class="alert alert-success">¡Documentos guardados correctamente!</div>
    <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
        <div class="alert alert-danger">⚠ Error: <?php echo htmlspecialchars($_GET['msg']); ?></div>
    <?php endif; ?>

    <!-- Tabla de documentos si ya existen -->
    <?php if ($tiene_documentos): ?>
        <div class="table-container">
            <h3 class="info-title">Mis Documentos de Encadenamiento</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Tipo de Documento</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?= render_document_row('Acta de Grados', $datos_usuario['Acta_Grados']); ?>
                    <?= render_document_row('Resultado ICFES', $datos_usuario['Resultado_ICFES']); ?>
                    <?= render_document_row('Actualizar EPS', $datos_usuario['Actualizar_EPS']); ?>
                    <?= render_document_row('Documento de Identidad', $datos_usuario['Documento_Identidad']); ?>
                </tbody>
            </table>

            <div style="text-align: center; margin-top: 20px;">
                <button id="toggleFormBtn" class="btn-primary" style="background: #ff9800;">🔄 Actualizar Documentos</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Formulario para subir documentos -->
    <div class="form-container" id="documentForm" style="display: <?= $tiene_documentos ? 'none' : 'block'; ?>; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-top: 30px;">
        <h3 class="info-title"><?= $tiene_documentos ? 'Actualizar Documentos' : 'Subir Documentos Requeridos'; ?></h3>
        
        <form action="procesar_encadenar.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="Acta_Grados">Acta de Grados</label>
                <input type="file" name="Acta_Grados" id="Acta_Grados" accept=".pdf" <?= !$tiene_documentos ? 'required' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="Resultado_ICFES">Resultado ICFES</label>
                <input type="file" name="Resultado_ICFES" id="Resultado_ICFES" accept=".pdf" <?= !$tiene_documentos ? 'required' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="Actualizar_EPS">Actualizar EPS</label>
                <input type="file" name="Actualizar_EPS" id="Actualizar_EPS" accept=".pdf" <?= !$tiene_documentos ? 'required' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="Documento_Identidad">Documento de Identidad</label>
                <input type="file" name="Documento_Identidad" id="Documento_Identidad" accept=".pdf" <?= !$tiene_documentos ? 'required' : ''; ?>>
            </div>
            <button type="submit" class="btn-primary">💾 Guardar Cambios</button>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('toggleFormBtn');
    if (toggleBtn) {
        const formContainer = document.getElementById('documentForm');
        toggleBtn.addEventListener('click', function() {
            const isHidden = formContainer.style.display === 'none';
            formContainer.style.display = isHidden ? 'block' : 'none';
            this.textContent = isHidden ? 'Ocultar Formulario' : '🔄 Actualizar Documentos';
        });
    }
});
</script>

</body>
</html>

<?php include("../../Conexion/cerrar_conexion.php"); ?>
