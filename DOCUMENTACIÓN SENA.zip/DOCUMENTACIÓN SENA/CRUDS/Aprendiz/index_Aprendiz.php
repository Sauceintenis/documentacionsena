<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$id_usuario = $_SESSION['Id_registro'];

// Consulta unificada para obtener datos del aprendiz y su estado
$stmt = $conexion->prepare("
SELECT r.es_menor_edad, a.* 
FROM registro r
LEFT JOIN aprendiz_sena a ON r.Id_registro = a.usuario_id
WHERE r.Id_registro = ?
");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$datos_usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();

$es_menor = ($datos_usuario['es_menor_edad'] === 'si');
$tiene_documentos = !empty($datos_usuario['Id']);

function render_document_row($label, $file_path) {
    $html = "<tr><td>{$label}</td>";
    if (!empty($file_path) && file_exists(__DIR__ . '/../../' . $file_path)) {
        $html .= '<td><span class="btn-sm btn-success">Cargado</span></td>';
        $html .= '<td><a href="../../' . htmlspecialchars($file_path) . '" target="_blank" class="btn-sm btn-info">Ver</a></td>';
    } else {
        $html .= '<td><span class="btn-sm btn-danger">Pendiente</span></td>';
        $html .= '<td><span class="text-muted">No disponible</span></td>';
    }
    $html .= "</tr>";
    return $html;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Documentos - SENA</title>
<link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container">
<nav class="navbar">
        <div class="navbar-container">
            <a href="Aprendiz.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
                <span class="logo-text">SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Aprendiz.php" class="nav-btn">🏠 Inicio</a>
                <a href="index_Aprendiz.php" class="nav-btn  active">📄 Mis Documentos</a>
                <a href="index_encadenar.php" class="nav-btn">⛓︎ Encadenamiento</a>
                <a href="perfil.php" class="nav-btn">👤 Mi Perfil</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

<div class="dashboard-content">
    <div class="welcome-section">
        <h1 class="welcome-title">Gestión de Documentos</h1>
        <p class="welcome-subtitle">Sube y administra tus documentos de matrícula.</p>
    </div>

    <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
        <div class="alert alert-success">¡Operación realizada con éxito!</div>
    <?php endif; ?>

    <?php if ($tiene_documentos): ?>
        <div class="table-container">
            <h3 class="info-title">Mis Documentos Cargados</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Tipo de Documento</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo render_document_row('Documento de Identidad', $datos_usuario['Tarjeta_Identidad']); ?>
                    <?php echo render_document_row('Registro Civil', $datos_usuario['Registro_civil']); ?>
                    <?php echo render_document_row('Certificado EPS', $datos_usuario['EPS']); ?>
                    <?php echo render_document_row('Firma del Aprendiz', $datos_usuario['Firma_Aprendiz']); ?>
                    <?php if ($es_menor): ?>
                        <?php echo render_document_row('Firma del Tutor', $datos_usuario['Firma_Tutor']); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div style="text-align: center; margin-top: 20px; display: flex; justify-content: center; gap: 15px; flex-wrap: wrap;">
                <a href="ver_compromiso.php?id=<?php echo $datos_usuario['Id']; ?>" target="_blank" class="btn-primary">📝 Ver Compromiso</a>
                <?php if ($es_menor): ?>
                    <a href="ver_tratamiento_datos.php?id=<?php echo $datos_usuario['Id']; ?>" target="_blank" class="btn-secondary">📄 Ver Tratamiento Datos</a>
                <?php endif; ?>
                <button id="toggleFormBtn" class="btn-primary" style="background: #ff9800; border-color: #ff9800;">🔄 Actualizar Documentos</button>
            </div>
        </div>
    <?php endif; ?>

    <div class="form-container" id="documentForm" style="display: <?php echo $tiene_documentos ? 'none' : 'block'; ?>; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-top: 30px;">
        <h3 class="info-title"><?php echo $tiene_documentos ? 'Actualizar Documentos' : 'Subir Documentos Requeridos'; ?></h3>
        
        <form action="procesar.php" method="post" enctype="multipart/form-data">
            <div class="form-section">
                <h3 class="section-title">Archivos (Solo PDF, máx 5MB)</h3>
                <div class="form-group">
                    <label for="Tarjeta_Identidad">Documento de Identidad</label>
                    <input type="file" name="Tarjeta_Identidad" id="Tarjeta_Identidad" accept=".pdf" <?php echo !$tiene_documentos ? 'required' : ''; ?>>
                </div>
                <div class="form-group">
                    <label for="Registro_civil">Registro Civil</label>
                    <input type="file" name="Registro_civil" id="Registro_civil" accept=".pdf" <?php echo !$tiene_documentos ? 'required' : ''; ?>>
                </div>
                <div class="form-group">
                    <label for="EPS">Certificado de Afiliación a EPS</label>
                    <input type="file" name="EPS" id="EPS" accept=".pdf" <?php echo !$tiene_documentos ? 'required' : ''; ?>>
                </div>
            </div>

            <div class="form-section">
                <h3 class="section-title">Firma del Aprendiz (Solo Imágenes: PNG, JPG)</h3>
                <div class="form-group">
                    <label for="Firma_Aprendiz">Tu Firma Digital</label>
                    <input type="file" name="Firma_Aprendiz" id="Firma_Aprendiz" accept="image/*" <?php echo !$tiene_documentos ? 'required' : ''; ?>>
                </div>
            </div>

            <?php if ($es_menor): ?>
            <div class="form-section">
                <h3 class="section-title">Firma del Tutor/Representante (Solo para menores de edad)</h3>
                <div class="form-group">
                    <label for="Firma_Tutor">Firma del Tutor</label>
                    <input type="file" name="Firma_Tutor" id="Firma_Tutor" accept="image/*" <?php echo !$tiene_documentos ? 'required' : ''; ?>>
                </div>
            </div>
            <?php endif; ?>

            <button type="submit" class="btn-primary">💾 Guardar Cambios</button>
        </form>
    </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
      const toggleBtn = document.getElementById('toggleFormBtn');
      if (toggleBtn) {
          const formContainer = document.getElementById('documentForm');
          toggleBtn.addEventListener('click', function() {
              const isHidden = formContainer.style.display === 'none';
              formContainer.style.display = isHidden ? 'block' : 'none';
              this.textContent = isHidden ? 'Ocultar Formulario' : '🔄 Actualizar Documentos';
          });
      }
  });
</script>
</body>
</html>
