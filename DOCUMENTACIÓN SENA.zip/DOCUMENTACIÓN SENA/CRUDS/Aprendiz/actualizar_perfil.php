<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: perfil.php');
    exit();
}

$id_usuario = $_SESSION['Id_registro'];
$current_password = $_POST['current_password'];
$new_password = $_POST['new_password'];
$confirm_new_password = $_POST['confirm_new_password'];

// 1. Verificar que la nueva contraseña y la confirmación coinciden
if ($new_password !== $confirm_new_password) {
    header('Location: perfil.php?status=error_mismatch');
    exit();
}

// 2. Obtener la contraseña actual hasheada de la base de datos
$stmt = $conexion->prepare("SELECT Contraseña FROM registro WHERE Id_registro = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario) {
    // Manejo de error si el usuario no se encuentra
    header('Location: perfil.php?status=error_generic');
    exit();
}

// 3. Verificar si la contraseña actual proporcionada es correcta
if (password_verify($current_password, $usuario['Contraseña'])) {
    // 4. Si es correcta, hashear la nueva contraseña y actualizarla en la BD
    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
    
    $update_stmt = $conexion->prepare("UPDATE registro SET Contraseña = ? WHERE Id_registro = ?");
    $update_stmt->bind_param("si", $hashed_new_password, $id_usuario);
    
    if ($update_stmt->execute()) {
        header('Location: perfil.php?status=success_password');
    } else {
        header('Location: perfil.php?status=error_generic');
    }
    $update_stmt->close();
} else {
    // Si la contraseña actual es incorrecta
    header('Location: perfil.php?status=error_password');
}

$stmt->close();
$conexion->close();
exit();
