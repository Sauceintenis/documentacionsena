<?php
session_start();
if(!isset($_SESSION['Usuario'])) {
    header("location: ../../index.php");
    exit();
}

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'] ?? '';
    $decision = $_POST['decision'] ?? '';
    $usuario = $_SESSION['Usuario'];
    
    // Obtener el ID del usuario desde la tabla registro
    $consulta_usuario = $conexion->prepare("SELECT Id_registro FROM registro WHERE Usuario = :usuario");
    $consulta_usuario->bindParam(':usuario', $usuario);
    $consulta_usuario->execute();
    $datos_usuario = $consulta_usuario->fetch(PDO::FETCH_ASSOC);
    
    if ($datos_usuario) {
        $usuario_id = $datos_usuario['Id_registro'];
        
        try {
            if ($tipo === 'compromiso') {
                // Verificar si ya existe un registro para este usuario
                $verificar = $conexion->prepare("SELECT id FROM aprendiz_sena WHERE usuario_id = :usuario_id");
                $verificar->bindParam(':usuario_id', $usuario_id);
                $verificar->execute();
                
                if ($verificar->rowCount() > 0) {
                    // Actualizar registro existente
                    $actualizar = $conexion->prepare("UPDATE aprendiz_sena SET compromiso_estado = :estado, compromiso_fecha = NOW() WHERE usuario_id = :usuario_id");
                    $actualizar->bindParam(':estado', $decision);
                    $actualizar->bindParam(':usuario_id', $usuario_id);
                    $actualizar->execute();
                } else {
                    // Crear nuevo registro
                    $insertar = $conexion->prepare("INSERT INTO aprendiz_sena (usuario_id, compromiso_estado, compromiso_fecha) VALUES (:usuario_id, :estado, NOW())");
                    $insertar->bindParam(':usuario_id', $usuario_id);
                    $insertar->bindParam(':estado', $decision);
                    $insertar->execute();
                }
                
                $mensaje = "Compromiso del Aprendiz: " . ucfirst($decision);
                $icono = $decision == 'aceptado' ? '✅' : '❌';
                
            } elseif ($tipo === 'tratamiento') {
                // Verificar si ya existe un registro para este usuario
                $verificar = $conexion->prepare("SELECT id FROM aprendiz_sena WHERE usuario_id = :usuario_id");
                $verificar->bindParam(':usuario_id', $usuario_id);
                $verificar->execute();
                
                if ($verificar->rowCount() > 0) {
                    // Actualizar registro existente
                    $actualizar = $conexion->prepare("UPDATE aprendiz_sena SET tratamiento_estado = :estado, tratamiento_fecha = NOW() WHERE usuario_id = :usuario_id");
                    $actualizar->bindParam(':estado', $decision);
                    $actualizar->bindParam(':usuario_id', $usuario_id);
                    $actualizar->execute();
                } else {
                    // Crear nuevo registro
                    $insertar = $conexion->prepare("INSERT INTO aprendiz_sena (usuario_id, tratamiento_estado, tratamiento_fecha) VALUES (:usuario_id, :estado, NOW())");
                    $insertar->bindParam(':usuario_id', $usuario_id);
                    $insertar->bindParam(':estado', $decision);
                    $insertar->execute();
                }
                
                $mensaje = "Tratamiento de Datos: " . ucfirst($decision);
                $icono = $decision == 'aceptado' ? '✅' : '❌';
            }
            
        } catch(PDOException $e) {
            $mensaje = "Error al procesar: " . $e->getMessage();
            $icono = '❌';
        }
    } else {
        $mensaje = "Error: Usuario no encontrado";
        $icono = '❌';
    }
} else {
    $mensaje = "Error: Método no permitido";
    $icono = '❌';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SENA - Resultado</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container">
    <div class="document-container fade-in">
        <div class="document-header">
            <h1 class="document-title"><?php echo $icono; ?> Resultado del Procesamiento</h1>
            <p class="document-subtitle"><?php echo htmlspecialchars($mensaje); ?></p>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="index_Aprendiz.php" class="btn-primary">🔙 Volver al formulario</a>
        </div>
    </div>
    
    <script>
        // Redirigir automáticamente después de 3 segundos
        setTimeout(function() {
            window.location.href = 'index_Aprendiz.php';
        }, 3000);
    </script>
</body>
</html>
