<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$id_usuario = $_SESSION['Id_registro'];

$stmt = $conexion->prepare("SELECT Nombre, Apellidos, tipo_documento, numero_documento, Correo FROM registro WHERE Id_registro = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario) {
    header('Location: ../../cerrar_sesion.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - SENA</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
</head>
<body class="dashboard-container">
<nav class="navbar">
        <div class="navbar-container">
            <a href="Aprendiz.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
                <span class="logo-text">SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Aprendiz.php" class="nav-btn">🏠 Inicio</a>
                <a href="index_Aprendiz.php" class="nav-btn">📄 Mis Documentos</a>
                <a href="index_encadenar.php" class="nav-btn">⛓︎ Encadenamiento</a>
                <a href="perfil.php" class="nav-btn active">👤 Mi Perfil</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="profile-container">
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($usuario['Nombre'], 0, 1) . substr($usuario['Apellidos'], 0, 1)); ?>
                </div>
                <h2 class="profile-name"><?php echo htmlspecialchars($usuario['Nombre'] . ' ' . $usuario['Apellidos']); ?></h2>
                <span class="profile-role">Aprendiz</span>
            </div>

            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] === 'success_password'): ?>
                    <div class="alert alert-success">Contraseña actualizada correctamente.</div>
                <?php elseif ($_GET['status'] === 'error_password'): ?>
                    <div class="alert alert-danger">Error: La contraseña actual es incorrecta.</div>
                <?php elseif ($_GET['status'] === 'error_mismatch'): ?>
                    <div class="alert alert-danger">Error: Las nuevas contraseñas no coinciden.</div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="info-section">
                <h3 class="info-title">📋 Información Personal</h3>
                <div class="info-item">
                    <span class="info-label">Nombre Completo:</span>
                    <span class="info-value"><?php echo htmlspecialchars($usuario['Nombre'] . ' ' . $usuario['Apellidos']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Tipo de Documento:</span>
                    <span class="info-value"><?php echo htmlspecialchars($usuario['tipo_documento']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Número de Documento:</span>
                    <span class="info-value"><?php echo htmlspecialchars($usuario['numero_documento']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Correo Electrónico:</span>
                    <span class="info-value"><?php echo htmlspecialchars($usuario['Correo']); ?></span>
                </div>
            </div>

            <div class="info-section">
                <h3 class="info-title">🔑 Cambiar Contraseña</h3>
                <form action="actualizar_perfil.php" method="POST">
                    <div class="form-group">
                        <label for="current_password">Contraseña Actual</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Nueva Contraseña</label>
                        <input type="password" id="new_password" name="new_password" required minlength="8">
                        <p class="form-text">Debe tener al menos 8 caracteres.</p>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Confirmar Nueva Contraseña</label>
                        <input type="password" id="confirm_new_password" name="confirm_new_password" required>
                    </div>
                    <button type="submit" class="btn-primary">Actualizar Contraseña</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
