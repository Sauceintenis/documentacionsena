<?php
session_start();
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

if (!isset($_SESSION['Id_registro'])) {
    header("Location: ../../index.php?error=access_denied");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index_Aprendiz.php");
    exit();
}

$id_usuario = $_SESSION['Id_registro'];

// Verificar si el usuario es menor de edad desde la BD
$stmt_user = $conexion->prepare("SELECT es_menor_edad FROM registro WHERE Id_registro = ?");
$stmt_user->bind_param("i", $id_usuario);
$stmt_user->execute();
$user_data = $stmt_user->get_result()->fetch_assoc();
$es_menor = ($user_data['es_menor_edad'] === 'si');
$stmt_user->close();

function procesarArchivo($campo, $directorio_fisico, $directorio_db, $tipos_permitidos) {
    if (isset($_FILES[$campo]) && $_FILES[$campo]['error'] === UPLOAD_ERR_OK) {
        if ($_FILES[$campo]['size'] > 5 * 1024 * 1024) return null;
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $finfo->file($_FILES[$campo]['tmp_name']);
        if (!in_array($mime_type, $tipos_permitidos)) return null;
        $nombre_archivo = uniqid() . '-' . basename($_FILES[$campo]['name']);
        $ruta_destino_fisica = $directorio_fisico . $nombre_archivo;
        $ruta_para_db = $directorio_db . $nombre_archivo;
        if (move_uploaded_file($_FILES[$campo]['tmp_name'], $ruta_destino_fisica)) {
            return $ruta_para_db;
        }
    }
    return null;
}

$directorio_fisico_base = __DIR__ . "/../../uploads/" . $id_usuario . "/";
$directorio_db_base = "uploads/" . $id_usuario . "/";

if (!is_dir($directorio_fisico_base)) {
    mkdir($directorio_fisico_base, 0777, true);
}

// --- Interacción con la Base de Datos ---
$stmt_check = $conexion->prepare("SELECT * FROM aprendiz_sena WHERE usuario_id = ?");
$stmt_check->bind_param("i", $id_usuario);
$stmt_check->execute();
$documentos_actuales = $stmt_check->get_result()->fetch_assoc();
$stmt_check->close();

$tipos_pdf = ['application/pdf'];
$tipos_img = ['image/png', 'image/jpeg', 'image/gif'];

// Procesar nuevos archivos
$ruta_ti_nueva = procesarArchivo('Tarjeta_Identidad', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_rc_nueva = procesarArchivo('Registro_civil', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_eps_nueva = procesarArchivo('EPS', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_firma_aprendiz_nueva = procesarArchivo('Firma_Aprendiz', $directorio_fisico_base, $directorio_db_base, $tipos_img);

$ruta_firma_tutor_nueva = null;
if ($es_menor) {
    $ruta_firma_tutor_nueva = procesarArchivo('Firma_Tutor', $directorio_fisico_base, $directorio_db_base, $tipos_img);
}

if ($documentos_actuales) {
    // UPDATE: Usar la nueva ruta si existe, si no, mantener la antigua.
    $ruta_ti_final = $ruta_ti_nueva ?? $documentos_actuales['Tarjeta_Identidad'];
    $ruta_rc_final = $ruta_rc_nueva ?? $documentos_actuales['Registro_civil'];
    $ruta_eps_final = $ruta_eps_nueva ?? $documentos_actuales['EPS'];
    $ruta_firma_aprendiz_final = $ruta_firma_aprendiz_nueva ?? $documentos_actuales['Firma_Aprendiz'];
    $ruta_firma_tutor_final = $ruta_firma_tutor_nueva ?? $documentos_actuales['Firma_Tutor'];

    $sql = "UPDATE aprendiz_sena SET 
                Tarjeta_Identidad = ?, Registro_civil = ?, EPS = ?, 
                Firma_Aprendiz = ?, Firma_Tutor = ?
            WHERE usuario_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sssssi", $ruta_ti_final, $ruta_rc_final, $ruta_eps_final, $ruta_firma_aprendiz_final, $ruta_firma_tutor_final, $id_usuario);
} else {
    // INSERT: Usar las nuevas rutas (pueden ser null si no se subió archivo)
    $sql = "INSERT INTO aprendiz_sena (usuario_id, Tarjeta_Identidad, Registro_civil, EPS, Firma_Aprendiz, Firma_Tutor) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("isssss", $id_usuario, $ruta_ti_nueva, $ruta_rc_nueva, $ruta_eps_nueva, $ruta_firma_aprendiz_nueva, $ruta_firma_tutor_nueva);
}

if ($stmt->execute()) {
    header("Location: index_Aprendiz.php?status=success");
} else {
    header("Location: index_Aprendiz.php?status=error");
}

$stmt->close();
$conexion->close();
exit();
