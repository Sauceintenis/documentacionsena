<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$nombre_usuario = htmlspecialchars($_SESSION['Nombre'] . ' ' . $_SESSION['Apellidos']);
$id_usuario = $_SESSION['Id_registro'];

// Consultar notificaciones no leídas
$stmt_notif = $conexion->prepare("SELECT * FROM notificaciones WHERE usuario_id = ? AND leida = 0 ORDER BY fecha_creacion DESC");
$stmt_notif->bind_param("i", $id_usuario);
$stmt_notif->execute();
$notificaciones = $stmt_notif->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>,.
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel del Aprendiz - SENA</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
    <style>
        /* Estilos del Carrusel */
        .carousel-container {
            position: relative;
            max-width: 1000px;
            margin: 30px auto;
            overflow: hidden;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            .news-item {
                flex-direction: column;
                gap: 15px;
            }

            .news-image {
                width: 100%;
                height: 120px;
                align-self: center;
            }

            .footer-info {
                grid-template-columns: 1fr;
                text-align: center;
            }
        }

        .carousel {
            position: relative;
            width: 100%;
            height: 400px;
        }

        .carousel-slide {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        .carousel-slide.active {
            opacity: 1;
            z-index: 1;
        }

        .carousel-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 15px;
        }

        .carousel-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0,0,0,0.7));
            color: white;
            padding: 40px 30px 30px;
            text-align: center;
            border-radius: 0 0 15px 15px;
        }

        .carousel-caption h3 {
            font-size: 24px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .carousel-caption p {
            font-size: 16px;
            margin-bottom: 15px;
            opacity: 0.9;
        }

        .carousel-btn {
            background: #4caf50;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin: 5px;
        }

        .carousel-btn:hover {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(76,175,80,0.3);
        }

        .carousel-prev, .carousel-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0,0,0,0.5);
            color: white;
            border: none;
            padding: 15px 20px;
            cursor: pointer;
            font-size: 18px;
            border-radius: 50%;
            transition: background 0.3s ease;
            z-index: 10;
        }

        .carousel-prev:hover, .carousel-next:hover {
            background: rgba(0,0,0,0.8);
        }

        .carousel-prev {
            left: 20px;
        }

        .carousel-next {
            right: 20px;
        }

        .carousel-dots {
            text-align: center;
            margin-top: 15px;
        }

        .dot {
            height: 12px;
            width: 12px;
            margin: 0 5px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .dot.active, .dot:hover {
            background-color: #4caf50;
        }

        /* Estilos adicionales para contenido ampliado */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin: 40px 0;
        }

        .info-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-left: 4px solid #4caf50;
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .info-card h3 {
            color: #4caf50;
            font-size: 22px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-card p {
            color: #666;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .info-card .highlight {
            background: #fff3e0;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 3px solid #4caf50;
        }

        .stats-section {
            background: linear-gradient(135deg, #4caf50, #45a049);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin: 40px 0;
            text-align: center;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }

        .stat-item {
            background: rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }

        .stat-number {
            font-size: 36px;
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        .news-section {
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin: 40px 0;
}

.news-item {
    padding: 20px;
    border-bottom: 1px solid #eee;
    transition: background 0.3s ease;
    display: flex;
    gap: 20px;
    align-items: flex-start;
}

.news-item:hover {
    background: #f8f9fa;
}

.news-item:last-child {
    border-bottom: none;
}

.news-content {
    flex: 1;
}

.news-image {
    width: 120px;
    height: 100px;
    border-radius: 10px;
    background: #f0f0f0;
    border: 2px solid #4caf50;
    flex-shrink: 0;
    position: relative;
    overflow: hidden;   /* recorta esquinas */
    display: block;
    padding: 0;
}

/* el ícono solo se muestra si no hay imagen */
.news-image::before {
    font-size: 24px;
    color: #4caf50;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.news-image img {
    display: block;           /* elimina espacio sobrante */
    width: 100%;
    height: 100%;
    object-fit: cover;        /* llena el recuadro */
    object-position: center;  /* centra la parte visible */
    border-radius: 0;         /* el redondeo lo maneja el padre */
}

.news-date {
    color: #4caf50;
    font-weight: bold;
    font-size: 14px;
}

.news-title {
    font-size: 18px;
    font-weight: bold;
    margin: 10px 0;
    color: #333;
}

.news-summary {
    color: #666;
    line-height: 1.5;
}


        .cta-section {
            background: white;
            color: #333;
            padding: 50px;
            border-radius: 15px;
            text-align: center;
            margin: 40px 0;
            border: 3px solid #4caf50;
            box-shadow: 0 5px 15px rgba(76,175,80,0.1);
        }

        .cta-title {
            font-size: 28px;
            margin-bottom: 15px;
            color: #4caf50;
        }

        .cta-subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 30px;
        }

        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .cta-btn {
            background: #4caf50;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .cta-btn:hover {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76,175,80,0.3);
        }

        .cta-btn.secondary {
            background: transparent;
            border: 2px solid #4caf50;
            color: #4caf50;
        }

        .cta-btn.secondary:hover {
            background: #4caf50;
            color: white;
        }

        /* Footer styles */
        .footer-section {
            background: #4caf50;
            color: white;
            padding: 40px;
            margin-top: 60px;
            border-radius: 15px 15px 0 0;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
        }

        .footer-title {
            font-size: 24px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .footer-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin: 30px 0;
            text-align: left;
        }

        .footer-column h4 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #ffffff;
            font-weight: bold;
        }

        .footer-column p {
            margin: 8px 0;
            line-height: 1.5;
            opacity: 0.9;
        }

        .sofia-link {
            background: white;
            color: #4caf50;
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin: 20px 10px;
            transition: all 0.3s ease;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }

        .sofia-link:hover {
            background: #f5f5f5;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.2);
            padding-top: 20px;
            margin-top: 30px;
            text-align: center;
            opacity: 0.8;
        }
        @media (max-width: 768px) {
            .carousel {
                height: 300px;
            }
            
            .carousel-caption {
                padding: 20px 15px 15px;
            }
            
            .carousel-caption h3 {
                font-size: 20px;
            }
            
            .carousel-caption p {
                font-size: 14px;
            }
            
            .carousel-prev, .carousel-next {
                padding: 10px 15px;
                font-size: 16px;
            }

            .info-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
            }

            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }

            .cta-btn {
                width: 100%;
                max-width: 300px;
            }
        }
        
    </style>
</head>
<body class="dashboard-container">
    <nav class="navbar">
        <div class="navbar-container">
            <a href="Aprendiz.php" class="navbar-logo">
                <div class="logo-icon"><img src="../../IMG/Logo.png" alt="SENA Logo"></div>
                <span class="logo-text">SENA</span>
            </a>
            <div class="navbar-menu">
                <a href="Aprendiz.php" class="nav-btn active">🏠 Inicio</a>
                <a href="index_Aprendiz.php" class="nav-btn">📄 Mis Documentos</a>
                <a href="index_encadenar.php" class="nav-btn">⛓︎ Encadenamiento</a>
                <a href="perfil.php" class="nav-btn">👤 Mi Perfil</a>
                <a href="../../cerrar_sesion.php" class="nav-btn">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="dashboard-content">
        <div class="welcome-section">
            <h1 class="welcome-title">Bienvenido, <?php echo $nombre_usuario; ?></h1>
            <p class="welcome-subtitle">Aquí puedes gestionar tus documentos y tu información personal en la plataforma académica del SENA.</p>
        </div>

        <!-- Carrusel de Imágenes -->
        <div class="carousel-container">
            <div class="carousel">
                <div class="carousel-slide active">
                    <img src="../../IMG/sena2.png" alt="Sistema SENA">
                    <div class="carousel-caption">
                        <h3>Sistema de Gestión Académica</h3>
                        <p>Accede a todos los servicios del SENA en un solo lugar</p>
                    </div>
                </div>
                <div class="carousel-slide">
                    <img src="../../IMG/sena3.png" alt="Seguridad SENA">
                    <div class="carousel-caption">
                        <h3>Seguridad y Confidencialidad</h3>
                        <p>Tus datos están protegidos con los más altos estándares de seguridad</p>
                    </div>
                </div>
                <div class="carousel-slide">
                    <img src="../../IMG/sena4.png" alt="Tarjeta SENA">
                    <div class="carousel-caption">
                        <h3>Documentación Digital</h3>
                        <p>Gestiona tus documentos de forma rápida y eficiente</p>
                    </div>
                </div>
                <div class="carousel-slide">
                    <img src="../../IMG/sena1.jpg" alt="Formación SENA">
                    <div class="carousel-caption">
                        <h3>Formación Integral</h3>
                        <p>Desarrolla competencias laborales y ciudadanas para tu futuro profesional</p>
                    </div>
                </div>
            </div>
            <button class="carousel-prev" onclick="changeSlide(-1)">❮</button>
            <button class="carousel-next" onclick="changeSlide(1)">❯</button>
            <div class="carousel-dots">
                <span class="dot active" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
                <span class="dot" onclick="currentSlide(4)"></span>
            </div>
        </div>

        <?php if (!empty($notificaciones)): ?>
        <div class="info-section" style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
            <h3 class="info-title">🔔 Notificaciones Pendientes</h3>
            <?php foreach ($notificaciones as $notificacion): ?>
                <div class="alert alert-warning">
                    <strong><?php echo htmlspecialchars($notificacion['tipo_notificacion']); ?>:</strong>
                    <?php echo htmlspecialchars($notificacion['mensaje']); ?>
                    <small style="display: block; text-align: right; margin-top: 5px;"><?php echo date('d/m/Y H:i', strtotime($notificacion['fecha_creacion'])); ?></small>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Estadísticas del SENA -->
        <div class="stats-section">
            <h2>El SENA en Cifras</h2>
            <p>Conoce el impacto de la formación profesional integral en Colombia</p>
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-number">9.8M+</span>
                    <span>Colombianos Formados</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">117</span>
                    <span>Centros de Formación</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">33</span>
                    <span>Departamentos</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">500+</span>
                    <span>Programas de Formación</span>
                </div>
            </div>
        </div>

        <!-- Información institucional -->
        <div class="info-grid">
            <div class="info-card">
                <h3>🎯 Nuestra Misión</h3>
                <p>El SENA está encargado de cumplir la función que le corresponde al Estado de invertir en el desarrollo social y técnico de los trabajadores colombianos, ofreciendo y ejecutando la formación profesional integral, para la incorporación y el desarrollo de las personas en actividades productivas que contribuyan al desarrollo social, económico y tecnológico del país.</p>
                <div class="highlight">
                    <strong>Formación Profesional Integral:</strong> Desarrollamos competencias técnicas, tecnológicas y de emprendimiento.
                </div>
            </div>



            <div class="info-card">
                <h3>⚖️ Nuestros Valores</h3>
                <p><strong>Respeto:</strong> Actuamos con consideración y reconocimiento de la dignidad propia y la de los demás.</p>
                <p><strong>Librepensamiento y Actitud Crítica:</strong> Fomentamos la construcción de nuevos conocimientos.</p>
                <p><strong>Liderazgo:</strong> Asumimos con responsabilidad y proactividad nuestro papel transformador.</p>
                <p><strong>Solidaridad:</strong> Actuamos con responsabilidad social, priorizando el bienestar colectivo.</p>
            </div>

            <div class="info-card">
                <h3>🚀 Modalidades de Formación</h3>
                <p><strong>Presencial:</strong> Formación en nuestros centros con instructores especializados y equipos de última tecnología.</p>
                <p><strong>Virtual:</strong> Accede a la formación desde cualquier lugar con nuestra plataforma digital SOFIA Plus.</p>
                <p><strong>A Distancia:</strong> Combina estudio autónomo con encuentros presenciales programados.</p>
                <div class="highlight">
                    <strong>Flexibilidad:</strong> Adaptamos la formación a tu ritmo de vida y necesidades.
                </div>
            </div>

            <div class="info-card">
                <h3>🏭 Sectores Productivos</h3>
                <p>Ofrecemos formación especializada en sectores estratégicos para el desarrollo económico del país:</p>
                <p>• <strong>Tecnologías de la Información:</strong> Desarrollo de software, ciberseguridad, análisis de datos</p>
                <p>• <strong>Salud y Bienestar:</strong> Auxiliar de enfermería, salud ocupacional, estética</p>
                <p>• <strong>Agroindustria:</strong> Producción agrícola, transformación de alimentos</p>
                <p>• <strong>Manufactura:</strong> Mecánica industrial, soldadura, automatización</p>
            </div>

            <div class="info-card">
                <h3>💼 Servicios Adicionales</h3>
                <p><strong>Bienestar al Aprendiz:</strong> Apoyo de sostenimiento, seguro estudiantil, actividades culturales y deportivas.</p>
                <p><strong>Bolsa de Empleo:</strong> Conectamos aprendices y egresados con oportunidades laborales.</p>
                <p><strong>Emprendimiento:</strong> Asesoría para crear y fortalecer empresas, acceso a capital semilla.</p>
                <p><strong>Certificación de Competencias:</strong> Reconocimiento oficial de saberes adquiridos por experiencia.</p>
            </div>
        </div>

        <!-- Noticias y Novedades -->
        <div class="news-section">
            <h2 style="color: #4caf50; margin-bottom: 30px; text-align: center;">📰 Noticias y Novedades</h2>
            <div class="news-item">
                <div class="news-content">
                    <div class="news-date">15 de Agosto, 2025</div>
                    <div class="news-title">Nuevos Programas de Formación en Inteligencia Artificial</div>
                    <div class="news-summary">El SENA lanza programas especializados en IA y Machine Learning, respondiendo a las necesidades del mercado laboral 4.0. Los aprendices podrán acceder a tecnología de vanguardia y certificaciones internacionales.</div>
                </div>
                <div class="news-image">
                    <img src="../../IMG/laboratorio_21072021.jpeg" alt="IA y Machine Learning" >
                </div>
            </div>
            <div class="news-item">
                <div class="news-content">
                    <div class="news-date">10 de Agosto, 2025</div>
                    <div class="news-title">Ampliación de la Oferta Virtual para 2025</div>
                    <div class="news-summary">Se incrementa en un 40% la oferta de programas virtuales, facilitando el acceso a la formación desde cualquier lugar del país. Nuevas herramientas digitales mejoran la experiencia de aprendizaje.</div>
                </div>
                <div class="news-image">
                    <img src="../../IMG/PXT3E2SW3RGULNP6JHGLXDC4DQ.jpg" alt="IA y Machine Learning" >
                </div>
            </div>
            <div class="news-item">
                <div class="news-content">
                    <div class="news-date">05 de Agosto, 2025</div>
                    <div class="news-title">Convenios Internacionales para Intercambio Académico</div>
                    <div class="news-summary">Nuevas alianzas con instituciones de España, Francia y Corea del Sur permiten a nuestros aprendices acceder a experiencias internacionales y doble titulación.</div>
                </div>
                <div class="news-image">
                    <img src="../../IMG/images.jpg" alt="IA y Machine Learning" >
                </div>
            </div>
            <div class="news-item">
                <div class="news-content">
                    <div class="news-date">01 de Agosto, 2025</div>
                    <div class="news-title">Programa de Sostenibilidad y Economia Circular</div>
                    <div class="news-summary">Lanzamiento de programas enfocados en sostenibilidad ambiental, energías renovables y economía circular, alineados con los objetivos de desarrollo sostenible.</div>
                </div>
                <div class="news-image">
                    <img src="../../IMG/descarga.jpg" alt="IA y Machine Learning" >
                </div>
            </div>
        </div>

        <!-- Call to Action -->
        <div class="cta-section">
            <h2 class="cta-title">¿Listo para Transformar tu Futuro?</h2>
            <p class="cta-subtitle">Únete a los millones de colombianos que han cambiado su vida con la formación del SENA</p>
            <div class="cta-buttons">
                <a href="index_Aprendiz.php" class="cta-btn">Ver Mis Documentos</a>
                <a href="perfil.php" class="cta-btn secondary">Actualizar Perfil</a>
            </div>
        </div>

        <!-- Tarjetas de funcionalidades principales -->
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">⛓️</div>
                <h2 class="feature-title">Encadenamiento</h2>
                <p class="feature-description">Accede a información sobre programas de formación complementarios y rutas de aprendizaje.</p>
                <a href="index_encadenar.php" class="feature-btn">Ver Encadenamiento</a>
            </div>
        </div>

        <!-- Footer - Contacto y Soporte -->
        <div class="footer-section">
            <div class="footer-content">
                <h2 class="footer-title">📞 Contacto y Soporte SENA</h2>
                <div class="footer-info">
                    <div class="footer-column">
                        <h4>Atención Telefónica</h4>
                        <p><strong>Línea Nacional:</strong> 018000 910270</p>
                        <p><strong>Línea en Bogotá:</strong> (601) 5461500</p>
                        <p><strong>Horario:</strong> Lunes a Viernes: 7:00 AM - 5:00 PM</p>
                        <p><strong>Sábados:</strong> 8:00 AM - 1:00 PM</p>
                    </div>
                    <div class="footer-column">
                        <h4>Atención Digital</h4>
                        <p><strong>Chat Virtual:</strong> Disponible 24/7</p>
                        <p><strong>Email:</strong> contacto@sena.edu.co</p>
                        <p><strong>Mesa de Servicios TI:</strong> soporte@sena.edu.co</p>
                        <p><strong>Redes Sociales:</strong> @SENAcolombia</p>
                    </div>
                    <div class="footer-column">
                        <h4>Servicios en Línea</h4>
                        <p><strong>SOFIA Plus:</strong> Gestión académica</p>
                        <p><strong>Territorium:</strong> Aula virtual</p>
                        <p><strong>Biblioteca Digital:</strong> Recursos bibliográficos</p>
                        <p><strong>Bolsa de Empleo:</strong> Oportunidades laborales</p>
                    </div>
                </div>
                
                <div style="margin: 30px 0;">
                    <a href="https://sofiaplus.sena.edu.co/" target="_blank" class="sofia-link">
                        🌐 Acceder a SOFIA Plus
                    </a>
                    <a href="https://www.sena.edu.co/" target="_blank" class="sofia-link">
                        🏢 Portal Oficial SENA
                    </a>
                </div>

                <div class="footer-bottom">
                    <p>&copy; <?php echo date('Y'); ?> SENA - Servicio Nacional de Aprendizaje. Todos los derechos reservados.</p>
                    <p>Institución de educación para el trabajo y el desarrollo humano. NIT 899.999.034-1</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Funcionalidad del Carrusel
        let slideIndex = 1;
        let autoSlideInterval;

        // Inicializar el carrusel
        showSlide(slideIndex);
        startAutoSlide();

        function changeSlide(n) {
            showSlide(slideIndex += n);
            resetAutoSlide();
        }

        function currentSlide(n) {
            showSlide(slideIndex = n);
            resetAutoSlide();
        }

        function showSlide(n) {
            let slides = document.getElementsByClassName("carousel-slide");
            let dots = document.getElementsByClassName("dot");
            
            if (n > slides.length) {slideIndex = 1}
            if (n < 1) {slideIndex = slides.length}
            
            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove("active");
            }
            
            for (let i = 0; i < dots.length; i++) {
                dots[i].classList.remove("active");
            }
            
            slides[slideIndex-1].classList.add("active");
            if (dots[slideIndex-1]) {
                dots[slideIndex-1].classList.add("active");
            }
        }

        function startAutoSlide() {
            autoSlideInterval = setInterval(function() {
                changeSlide(1);
            }, 4000); // Cambiar cada 4 segundos
        }

        function resetAutoSlide() {
            clearInterval(autoSlideInterval);
            startAutoSlide();
        }

        // Pausar el carrusel cuando el mouse está sobre él
        document.querySelector('.carousel-container').addEventListener('mouseenter', function() {
            clearInterval(autoSlideInterval);
        });

        // Reanudar el carrusel cuando el mouse sale
        document.querySelector('.carousel-container').addEventListener('mouseleave', function() {
            startAutoSlide();
        });

        // Función para redirigir a diferentes secciones
        function redirectTo(section) {
            switch(section) {
                case 'documentos':
                    window.location.href = 'index_Aprendiz.php';
                    break;
                case 'perfil':
                    window.location.href = 'perfil.php';
                    break;
                case 'encadenamiento':
                    window.location.href = 'index_encadenar.php';
                    break;
            }
        }

        // Animación suave para elementos al hacer scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Aplicar animación a las tarjetas
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.info-card, .feature-card, .news-section, .stats-section, .cta-section');
            cards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(card);
            });
        });
    </script>
</body>
</html>
