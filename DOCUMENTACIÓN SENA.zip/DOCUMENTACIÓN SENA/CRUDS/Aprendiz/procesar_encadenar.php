<?php
session_start();
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

if (!isset($_SESSION['Id_registro'])) {
    header("Location: ../../index.php?error=access_denied");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index_encadenar.php");
    exit();
}

$id_usuario = $_SESSION['Id_registro'];

// Función para procesar archivos
function procesarArchivo($campo, $directorio_fisico, $directorio_db, $tipos_permitidos) {
    if (isset($_FILES[$campo]) && $_FILES[$campo]['error'] === UPLOAD_ERR_OK) {
        // Verificar tamaño (máximo 5MB)
        if ($_FILES[$campo]['size'] > 5 * 1024 * 1024) {
            return null;
        }
        
        // Verificar tipo MIME
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $finfo->file($_FILES[$campo]['tmp_name']);
        if (!in_array($mime_type, $tipos_permitidos)) {
            return null;
        }
        
        // Generar nombre único
        $nombre_archivo = time() . '-' . basename($_FILES[$campo]['name']);
        $ruta_destino_fisica = $directorio_fisico . $nombre_archivo;
        $ruta_para_db = $directorio_db . $nombre_archivo;
        
        // Mover archivo
        if (move_uploaded_file($_FILES[$campo]['tmp_name'], $ruta_destino_fisica)) {
            return $ruta_para_db;
        }
    }
    return null;
}

// Configurar directorios
$directorio_fisico_base = __DIR__ . "/../../Documentos/Encadenamiento/" . $id_usuario . "/";
$directorio_db_base = "Documentos/Encadenamiento/" . $id_usuario . "/";

// Crear directorio si no existe
if (!is_dir($directorio_fisico_base)) {
    mkdir($directorio_fisico_base, 0777, true);
}

// Verificar si ya existen documentos
$stmt_check = $conexion->prepare("SELECT * FROM encadenamiento_sena WHERE usuario_id = ?");
$stmt_check->bind_param("i", $id_usuario);
$stmt_check->execute();
$documentos_actuales = $stmt_check->get_result()->fetch_assoc();
$stmt_check->close();

$tipos_pdf = ['application/pdf'];

// Procesar nuevos archivos
$ruta_acta_nueva = procesarArchivo('Acta_Grados', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_icfes_nueva = procesarArchivo('Resultado_ICFES', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_eps_nueva = procesarArchivo('Actualizar_EPS', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);
$ruta_doc_nueva = procesarArchivo('Documento_Identidad', $directorio_fisico_base, $directorio_db_base, $tipos_pdf);

if ($documentos_actuales) {
    // UPDATE: Usar la nueva ruta si existe, si no, mantener la antigua
    $ruta_acta_final = $ruta_acta_nueva ?? $documentos_actuales['Acta_Grados'];
    $ruta_icfes_final = $ruta_icfes_nueva ?? $documentos_actuales['Resultado_ICFES'];
    $ruta_eps_final = $ruta_eps_nueva ?? $documentos_actuales['Actualizar_EPS'];
    $ruta_doc_final = $ruta_doc_nueva ?? $documentos_actuales['Documento_Identidad'];

    // Usar fecha_actualizacion (que existe en tu BD) en lugar de fecha_creacion
    $sql = "UPDATE encadenamiento_sena SET 
                Acta_Grados = ?, Resultado_ICFES = ?, Actualizar_EPS = ?, Documento_Identidad = ?,
                fecha_actualizacion = CURRENT_TIMESTAMP
            WHERE usuario_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssssi", $ruta_acta_final, $ruta_icfes_final, $ruta_eps_final, $ruta_doc_final, $id_usuario);
} else {
    // INSERT: Usar las nuevas rutas (fecha_subida se asigna automáticamente)
    $sql = "INSERT INTO encadenamiento_sena (usuario_id, Acta_Grados, Resultado_ICFES, Actualizar_EPS, Documento_Identidad) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("issss", $id_usuario, $ruta_acta_nueva, $ruta_icfes_nueva, $ruta_eps_nueva, $ruta_doc_nueva);
}

if ($stmt->execute()) {
    header("Location: index_encadenar.php?status=success");
} else {
    header("Location: index_encadenar.php?status=error&msg=" . urlencode("Error al guardar en la base de datos"));
}

$stmt->close();
$conexion->close();
exit();
?>
