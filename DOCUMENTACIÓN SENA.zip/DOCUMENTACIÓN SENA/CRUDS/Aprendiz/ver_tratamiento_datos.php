<?php
require_once __DIR__ . '/../../incluidos/guardia_autenticacion.php';
require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

$id_documento = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id_documento) {
    die("ID de documento no válido.");
}

// Consulta para obtener todos los datos necesarios
$stmt = $conexion->prepare("
    SELECT 
        r.es_menor_edad,
        r.Nombre AS nombre_aprendiz,
        r.Apellidos AS apellidos_aprendiz,
        r.numero_documento AS doc_aprendiz,
        r.nombre_completo_representante,
        r.tipo_documento_representante,
        r.numero_documento_representante,
        r.Correo,
        r.Direccion_contacto,
        a.Firma_Aprendiz,
        a.Firma_Tutor
    FROM aprendiz_sena a
    JOIN registro r ON a.usuario_id = r.Id_registro
    WHERE a.Id = ?
");
$stmt->bind_param("i", $id_documento);
$stmt->execute();
$datos = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conexion->close();

// *** ¡VERIFICACIÓN DE SEGURIDAD! ***
if (!$datos || $datos['es_menor_edad'] !== 'si') {
    die("Acceso denegado: Este documento solo es aplicable a aprendices menores de edad.");
}

$nombre_completo_aprendiz = htmlspecialchars($datos['nombre_aprendiz'] . ' ' . $datos['apellidos_aprendiz']);
$nombre_completo_representante = htmlspecialchars($datos['nombre_completo_representante']);
$es_cc = ($datos['tipo_documento_representante'] === 'CC') ? 'X' : '_';
$es_ce = ($datos['tipo_documento_representante'] === 'CE') ? 'X' : '_';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tratamiento de Datos Personales</title>
    <link rel="stylesheet" href="../../CSS/Estilos.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body { font-family: 'Helvetica', 'Arial', sans-serif; font-size: 10pt; line-height: 1.4; color: #333; }
        .container { max-width: 800px; margin: 20px auto; padding: 30px; border: 1px solid #ccc; background: #fff; }
        .header { text-align: center; margin-bottom: 25px; font-weight: bold; }
        .content { text-align: justify; }
        .firma-area { margin-top: 40px; text-align: center; }
        .firma-img { max-height: 60px; max-width: 200px; display: block; margin: 0 auto 10px; }
        .form-line { border-bottom: 1px solid #000; padding: 0 5px; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" class="btn-document secondary">Imprimir</button>
        <a href="index_Aprendiz.php" class="btn-document secondary">Volver</a>
    </div>
    <div class="container" id="document-to-print">
        <div class="header">
            <h1>AUTORIZACIÓN TRATAMIENTO DE DATOS PERSONALES</h1>
            <p>Ley 1581 de 2012 - Decreto 1377 de 2013</p>
        </div>
        <div class="content">
            <p>
                Yo <span class="form-line"><?php echo $nombre_completo_representante; ?></span>, 
                identificado con Cédula de Ciudadanía <span class="form-line"><?php echo $es_cc; ?></span> 
                o Extranjería <span class="form-line"><?php echo $es_ce; ?></span> 
                No. <span class="form-line"><?php echo htmlspecialchars($datos['numero_documento_representante']); ?></span>,
                declaro bajo la gravedad de juramento que soy el representante legal o tutor del titular de los datos personales del menor de edad, 
                <span class="form-line"><?php echo $nombre_completo_aprendiz; ?></span>, 
                identificado con la tarjeta de identidad número <span class="form-line"><?php echo htmlspecialchars($datos['doc_aprendiz']); ?></span>, 
                y conforme a la ley 1581 de 2012 y demás Decretos reglamentarios:
            </p>
            <p><strong>AUTORIZO</strong> de manera voluntaria, previa, explicita, informada e inequívoca al Servicio Nacional de Aprendizaje - SENA...</p>
            <p>De conformidad con la Ley 1581 de 2012 y sus Decretos reglamentarios, declaro que he sido informado de lo siguiente...</p>
            <p>Atentamente,</p>
        </div>
        <div class="firma-area">
            <?php if (!empty($datos['Firma_Tutor']) && file_exists(__DIR__ . '/../../' . $datos['Firma_Tutor'])): ?>
                <img src="../../<?php echo htmlspecialchars($datos['Firma_Tutor']); ?>" alt="Firma del Tutor" class="firma-img">
            <?php else: ?>
                <div style="height: 60px; text-align: center; color: #999;">Firma no disponible</div>
            <?php endif; ?>
            <div style="border-top: 1px solid #000; padding-top: 5px; display: inline-block;">
                <strong><?php echo $nombre_completo_representante; ?></strong><br>
                <?php echo htmlspecialchars($datos['tipo_documento_representante'] . ' ' . $datos['numero_documento_representante']); ?><br>
                Fecha: <?php echo date('d/m/Y'); ?>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('download-pdf-btn').addEventListener('click', function () {
            const element = document.getElementById('document-to-print');
            const opt = {
                margin:       0.5,
                filename:     'Tratamiento-Datos-SENA.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            
            html2pdf().from(element).set(opt).save();
        });
    </script>
</body>
</html>
