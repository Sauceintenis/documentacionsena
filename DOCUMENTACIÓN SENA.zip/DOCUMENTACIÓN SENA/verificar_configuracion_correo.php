<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Configuración de Correo - SENA</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .success { color: #4caf50; font-weight: bold; }
        .error { color: #f44336; font-weight: bold; }
        .warning { color: #ff9800; font-weight: bold; }
        .info { color: #2196f3; font-weight: bold; }
        .section { background: #f9f9f9; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #4caf50; }
        .code { background: #f0f0f0; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }
        .step { background: #e3f2fd; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 3px solid #2196f3; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Diagnóstico de Configuración de Correo</h1>
        
        <?php
        echo "<div class='section'>";
        echo "<h2>📁 Verificación de Archivos PHPMailer</h2>";
        
        $archivos_phpmailer = [
            'PHPMailer/src/PHPMailer.php',
            'PHPMailer/src/SMTP.php',
            'PHPMailer/src/Exception.php'
        ];
        
        $todos_existen = true;
        foreach ($archivos_phpmailer as $archivo) {
            if (file_exists($archivo)) {
                echo "<p class='success'>✅ $archivo - Existe</p>";
            } else {
                echo "<p class='error'>❌ $archivo - NO EXISTE</p>";
                $todos_existen = false;
            }
        }
        echo "</div>";
        
        if ($todos_existen) {
            echo "<div class='section'>";
            echo "<h2>🧪 Prueba de Carga de PHPMailer</h2>";
            
            try {
                require_once 'PHPMailer/src/PHPMailer.php';
                require_once 'PHPMailer/src/SMTP.php';
                require_once 'PHPMailer/src/Exception.php';
                
                use PHPMailer\PHPMailer\PHPMailer;
                use PHPMailer\PHPMailer\SMTP;
                use PHPMailer\PHPMailer\Exception;
                
                $mail = new PHPMailer(true);
                echo "<p class='success'>✅ PHPMailer se cargó correctamente</p>";
                echo "<p class='info'>📊 Versión: " . PHPMailer::VERSION . "</p>";
                
            } catch (Exception $e) {
                echo "<p class='error'>❌ Error al cargar PHPMailer: " . $e->getMessage() . "</p>";
            }
            echo "</div>";
        }
        
        echo "<div class='section'>";
        echo "<h2>⚙️ Configuración Requerida</h2>";
        echo "<p class='warning'>⚠️ Para que funcione el envío de correos, debes:</p>";
        
        echo "<div class='step'>";
        echo "<h3>1. Configurar Gmail</h3>";
        echo "<p>• Ve a tu cuenta de Gmail</p>";
        echo "<p>• Activa la verificación en 2 pasos</p>";
        echo "<p>• Genera una contraseña de aplicación</p>";
        echo "<p>• <strong>NO uses tu contraseña normal de Gmail</strong></p>";
        echo "</div>";
        
        echo "<div class='step'>";
        echo "<h3>2. Editar el archivo Controlador/nuevo.php</h3>";
        echo "<p>Busca estas líneas y cámbialas:</p>";
        echo "<div class='code'>";
        echo "\$mail->Username = 'TU_CORREO@gmail.com';<br>";
        echo "\$mail->Password = 'TU_CONTRASEÑA_DE_APLICACION';";
        echo "</div>";
        echo "<p><strong>Ejemplo:</strong></p>";
        echo "<div class='code'>";
        echo "\$mail->Username = 'miCorreo@gmail.com';<br>";
        echo "\$mail->Password = 'abcd efgh ijkl mnop'; // Contraseña de aplicación";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='step'>";
        echo "<h3>3. Probar el Sistema</h3>";
        echo "<p>• Registra un usuario nuevo</p>";
        echo "<p>• Usa un correo real para recibir la confirmación</p>";
        echo "<p>• Si no funciona, revisa los logs de error</p>";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='section'>";
        echo "<h2>🔧 Información del Sistema</h2>";
        echo "<p><strong>Ruta actual:</strong> " . __DIR__ . "</p>";
        echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";
        echo "<p><strong>Función mail() disponible:</strong> " . (function_exists('mail') ? 'Sí' : 'No') . "</p>";
        echo "<p><strong>OpenSSL habilitado:</strong> " . (extension_loaded('openssl') ? 'Sí' : 'No') . "</p>";
        echo "</div>";
        
        if (!$todos_existen) {
            echo "<div class='section'>";
            echo "<h2>📥 Cómo Instalar PHPMailer</h2>";
            echo "<div class='step'>";
            echo "<h3>Opción 1: Descarga Manual</h3>";
            echo "<p>1. Ve a <a href='https://github.com/PHPMailer/PHPMailer/releases' target='_blank'>GitHub PHPMailer</a></p>";
            echo "<p>2. Descarga la última versión</p>";
            echo "<p>3. Extrae el archivo</p>";
            echo "<p>4. Copia la carpeta 'src' a tu proyecto como 'PHPMailer/src/'</p>";
            echo "</div>";
            echo "</div>";
        }
        ?>
        
        <div class="section">
            <h2>🎯 Próximos Pasos</h2>
            <ol>
                <li><strong>Configura Gmail:</strong> Activa 2FA y genera contraseña de aplicación</li>
                <li><strong>Edita nuevo.php:</strong> Cambia las credenciales de correo</li>
                <li><strong>Prueba el registro:</strong> Registra un usuario con correo real</li>
                <li><strong>Revisa errores:</strong> Si falla, verifica los logs de PHP</li>
            </ol>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="Registro.php" style="background: #4caf50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold;">
                🧪 Probar Registro
            </a>
        </div>
    </div>
</body>
</html>
