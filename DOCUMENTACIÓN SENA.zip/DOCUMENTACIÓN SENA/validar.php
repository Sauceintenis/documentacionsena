<?php
session_start();

// 1. Validar que se recibieron los datos
if (!isset($_POST['numero_documento']) || !isset($_POST['Contraseña'])) {
    header("location: index.php?error=Datos incompletos");
    exit();
}

$NumeroDocumento = trim($_POST['numero_documento']);
$Contraseña = trim($_POST['Contraseña']);

if (empty($NumeroDocumento) || empty($Contraseña)) {
    header("location: index.php?error=Número de documento y contraseña son requeridos");
    exit();
}

// 2. Conexión a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "documentacion_sena");
if (!$conexion) {
    header("location: index.php?error=Error de conexión a la base de datos");
    exit();
}
mysqli_set_charset($conexion, "utf8");

// 3. Preparar consulta para buscar al usuario
$consulta = "SELECT * FROM registro WHERE numero_documento = ?";
$stmt = mysqli_prepare($conexion, $consulta);
mysqli_stmt_bind_param($stmt, "s", $NumeroDocumento);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($resultado) > 0) {
    $filas = mysqli_fetch_assoc($resultado);
    
    // 4. Verificar la contraseña
    if (password_verify($Contraseña, $filas['Contraseña'])) {
        // Iniciar sesión
        $_SESSION['Id_registro'] = $filas['Id_registro'];
        $_SESSION['Nombre'] = $filas['Nombre'];
        $_SESSION['Apellidos'] = $filas['Apellidos'];
        $_SESSION['Rol'] = $filas['Rol'];

        // 5. Lógica de "Recordar sesión"
        if (isset($_POST['remember'])) {
            $selector = bin2hex(random_bytes(16));
            $validator = bin2hex(random_bytes(32));
            $token_hash = hash('sha256', $validator);
            $expires = new DateTime('now');
            $expires->add(new DateInterval('P30D')); // Expira en 30 días

            setcookie('remember_me', $selector . ':' . $validator, [
                'expires' => $expires->getTimestamp(),
                'path' => '/',
                'httponly' => true,
                'samesite' => 'Lax'
            ]);

            $update_token_sql = "UPDATE registro SET remember_selector = ?, remember_token_hash = ?, remember_expires = ? WHERE Id_registro = ?";
            $stmt_token = mysqli_prepare($conexion, $update_token_sql);
            mysqli_stmt_bind_param($stmt_token, "sssi", $selector, $token_hash, $expires->format('Y-m-d H:i:s'), $filas['Id_registro']);
            mysqli_stmt_execute($stmt_token);
        } else {
            // Si no se marca, limpiar cualquier token existente para este usuario
            $clear_token_sql = "UPDATE registro SET remember_selector = NULL, remember_token_hash = NULL, remember_expires = NULL WHERE Id_registro = ?";
            $stmt_clear = mysqli_prepare($conexion, $clear_token_sql);
            mysqli_stmt_bind_param($stmt_clear, "i", $filas['Id_registro']);
            mysqli_stmt_execute($stmt_clear);
        }

        // 6. Redirigir según el rol
        switch($filas['Rol']) {
            case 1: header("location: CRUDS/Aprendiz/Aprendiz.php"); break;
            case 2: header("location: CRUDS/Administrador/Administrador.php"); break;
            default: header("location: index.php?error=Rol no válido"); break;
        }
        exit();
    } else {
        header("location: index.php?error=Error en la autenticación");
    }
} else {
    header("location: index.php?error=Error en la autenticación");
}

mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>
