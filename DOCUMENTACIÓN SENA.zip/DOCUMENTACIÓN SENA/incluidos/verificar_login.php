<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Si el usuario ya tiene una sesión, lo redirigimos a su panel
if (isset($_SESSION['Id_registro'])) {
    if ($_SESSION['Rol'] == 1) {
        header('Location: CRUDS/Aprendiz/Aprendiz.php');
        exit();
    } elseif ($_SESSION['Rol'] == 2) {
        header('Location: CRUDS/Administrador/Administrador.php');
        exit();
    }
}

// Si no hay sesión, pero sí una cookie "recordar", intentamos iniciar sesión
if (!isset($_SESSION['Id_registro']) && isset($_COOKIE['remember_me'])) {
    $conexion = mysqli_connect("localhost", "root", "", "documentacion_sena");
    if ($conexion) {
        mysqli_set_charset($conexion, "utf8");
        
        list($selector, $validator) = explode(':', $_COOKIE['remember_me'], 2);

        if ($selector && $validator) {
            $sql = "SELECT * FROM registro WHERE remember_selector = ? AND remember_expires >= NOW()";
            $stmt = mysqli_prepare($conexion, $sql);
            mysqli_stmt_bind_param($stmt, "s", $selector);
            mysqli_stmt_execute($stmt);
            $resultado = mysqli_stmt_get_result($stmt);
            $user = mysqli_fetch_assoc($resultado);

            if ($user) {
                $token_hash_from_db = $user['remember_token_hash'];
                $token_hash_from_cookie = hash('sha256', $validator);

                if (hash_equals($token_hash_from_db, $token_hash_from_cookie)) {
                    // ¡Éxito! Las llaves coinciden. Iniciamos sesión.
                    session_regenerate_id(true); // Previene la fijación de sesión
                    $_SESSION['Id_registro'] = $user['Id_registro'];
                    $_SESSION['Nombre'] = $user['Nombre'];
                    $_SESSION['Apellidos'] = $user['Apellidos'];
                    $_SESSION['Rol'] = $user['Rol'];

                    // Redirigir al panel correspondiente
                    if ($_SESSION['Rol'] == 1) {
                        header('Location: CRUDS/Aprendiz/Aprendiz.php');
                        exit();
                    } elseif ($_SESSION['Rol'] == 2) {
                        header('Location: CRUDS/Administrador/Administrador.php');
                        exit();
                    }
                }
            }
        }
        mysqli_close($conexion);
    }
}
?>
