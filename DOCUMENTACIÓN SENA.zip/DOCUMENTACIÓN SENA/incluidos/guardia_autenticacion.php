<?php
// Este script se incluye al inicio de cada página protegida
// para asegurar que solo usuarios autenticados puedan acceder.

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 1. Si no hay una sesión activa, verificar la cookie "recordar"
if (!isset($_SESSION['Id_registro'])) {
    if (isset($_COOKIE['remember_selector']) && isset($_COOKIE['remember_token'])) {
        // La ruta a la conexión puede variar. Esta ruta asume que el guardia
        // se llama desde un archivo dentro de una subcarpeta de CRUDS (ej. /CRUDS/Aprendiz/).
        require_once __DIR__ . '/../../Conexion/abrir_conexion.php';

        $selector = $_COOKIE['remember_selector'];
        $token = $_COOKIE['remember_token'];

        $sql = "SELECT * FROM registro WHERE remember_selector = :selector AND remember_expires >= NOW()";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':selector' => $selector]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if (hash_equals(hash('sha256', $token), $user['remember_token_hash'])) {
                // Cookie válida, iniciar sesión
                $_SESSION['Id_registro'] = $user['Id_registro'];
                $_SESSION['Nombre'] = $user['Nombre'];
                $_SESSION['Apellidos'] = $user['Apellidos'];
                $_SESSION['Rol'] = $user['Rol'];
            } else {
                // Cookie inválida, redirigir al login
                header('Location: ../../index.php');
                exit();
            }
        } else {
            // Cookie no encontrada o expirada, redirigir al login
            header('Location: ../../index.php');
            exit();
        }
    } else {
        // No hay sesión ni cookie, redirigir al login
        header('Location: ../../index.php');
        exit();
    }
}

// Si el script llega hasta aquí, el usuario está correctamente autenticado.
?>
