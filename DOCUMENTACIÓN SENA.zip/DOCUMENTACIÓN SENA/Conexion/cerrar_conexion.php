<?php
// Cerrar la conexión
if (isset($conexion)) {
    mysqli_close($conexion);
}
?>
