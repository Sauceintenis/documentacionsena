<?php
// Parámetros de conexión
$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "documentacion_sena";
$tabla_db1 = "registro"; // Tabla principal de usuarios

// Crear conexión
$conexion = mysqli_connect($host, $usuario, $password, $base_datos);

// Verificar conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Configurar charset para evitar problemas con caracteres especiales
mysqli_set_charset($conexion, "utf8");
?>
