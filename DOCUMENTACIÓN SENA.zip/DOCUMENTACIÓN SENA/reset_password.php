<?php
// reset_password.php
session_start();
require_once 'Conexion/abrir_conexion.php';

// Validar token en la URL
$token = $_GET['token'] ?? '';
if (empty($token)) {
    die("Token inválido o expirado.");
}

// Verificar que el token exista y no haya expirado
$stmt = $conexion->prepare("SELECT usuario_id FROM password_resets WHERE token = ? AND fecha_expiracion > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("El enlace ha expirado o es inválido.");
}

$user = $result->fetch_assoc();
$stmt->close();

// Procesar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nueva = $_POST['nueva_contraseña'] ?? '';
    $confirmar = $_POST['confirmar_contraseña'] ?? '';

    // Expresión regular para validar seguridad
    $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/';

    if ($nueva !== $confirmar) {
        echo "<script>alert('Las contraseñas no coinciden.'); window.history.back();</script>";
        exit;
    }

    if (!preg_match($regex, $nueva)) {
        echo "<script>alert('La contraseña debe tener mínimo 8 caracteres, incluir mayúsculas, minúsculas, números y caracteres especiales.'); window.history.back();</script>";
        exit;
    }

    // Encriptar nueva contraseña
    $nueva_cifrada = password_hash($nueva, PASSWORD_DEFAULT);

    // Actualizar contraseña y eliminar token
    $stmt = $conexion->prepare("UPDATE registro r
        JOIN password_resets pr ON r.Id_registro = pr.usuario_id
        SET r.Contraseña = ?, pr.token = NULL
        WHERE pr.token = ?");
    $stmt->bind_param("ss", $nueva_cifrada, $token);

    if ($stmt->execute()) {
        echo "<script>alert('Tu contraseña ha sido restablecida con éxito.'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar la contraseña. Intenta de nuevo.'); window.history.back();</script>";
    }
    $stmt->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Restablecer contraseña</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
        :root{
            --primary: #2196f3;
            --primary-dark: #1976d2;
            --muted: #777;
            --bg: #f4f7f6;
            --card: #fff;
        }
        html,body{height:100%;}
        body { font-family: Arial, sans-serif; background: var(--bg); display: flex; align-items: center; justify-content: center; padding:20px; }

        .container { background: var(--card); padding: 28px; border-radius: 10px; width: 100%; max-width: 440px; box-shadow: 0 6px 20px rgba(0,0,0,0.08); }
        h2 { text-align: left; color: var(--primary); margin: 0 0 12px 0; display:flex; align-items:center; gap:10px; font-size:22px; }
        h2 .key { font-size:20px; display:inline-block; transform: translateY(1px); } /* pequeño ajuste visual */

        label { display: block; margin: 14px 0 6px; font-weight: 600; color: #222; }
        input[type="password"], input[type="text"] { width: 100%; padding: 12px 14px; border: 1px solid #e0e0e0; border-radius: 8px; font-size: 14px; box-sizing: border-box; }

        /* espacio a la derecha para que no tape el icono */
        .password-container input { padding-right: 46px; }

        .password-container { position: relative; margin-bottom: 6px; }

        /* botón del ojo (tipo button para evitar submit) */
        .toggle-eye {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            height: 34px;
            width: 34px;
            padding: 6px;
            border-radius: 6px;
            border: none;
            background: transparent;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background .12s ease;
        }
        .toggle-eye:focus{ outline: 2px solid rgba(33,150,243,0.25); }

        /* SVG icon styling */
        .toggle-eye .icon { width: 20px; height: 20px; display: block; transition: transform .18s ease, opacity .18s ease, fill .18s ease; fill: var(--muted); }
        /* states: when active (visible password) */
        .toggle-eye.active .icon-open { opacity: 1; transform: scale(1.12); fill: var(--primary); }
        .toggle-eye.active .icon-closed { opacity: 0; transform: scale(0.92); }
        .toggle-eye .icon-open { opacity: 0; transform: scale(0.92); }
        .toggle-eye .icon-closed { opacity: 1; transform: scale(1); }

        /* hover effect */
        .toggle-eye:hover { background: rgba(0,0,0,0.02); }
        .toggle-eye:hover .icon { transform: scale(1.05); }

        button[type="submit"] { width: 100%; margin-top: 16px; padding: 12px; background: var(--primary); color: #fff; border: none; border-radius: 8px; font-size: 15px; cursor: pointer; }
        button[type="submit"]:hover{ background: var(--primary-dark); }

        .requisitos { font-size: 13px; color: #555; margin-top: 10px; line-height:1.4; }

        .note { font-size: 13px; color:#999; margin-top:12px; text-align:center; }
    </style>
</head>
<body>
    <div class="container" role="main">
        <h2><span class="key">🔑</span> Restablecer contraseña</h2>

        <form method="POST" onsubmit="return validarPassword();" novalidate>
            <label for="nueva_contraseña">Nueva contraseña</label>
            <div class="password-container">
                <input
                    type="password"
                    id="nueva_contraseña"
                    name="nueva_contraseña"
                    required
                    autocomplete="new-password"
                    pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$"
                    title="Debe tener mínimo 8 caracteres, incluyendo mayúsculas, minúsculas, números y caracteres especiales"
                />

                <!-- botón del ojo con SVGs (open + closed) -->
                <button type="button" id="togglePasswordBtn" class="toggle-eye" aria-pressed="false" aria-label="Mostrar contraseña">
                    <!-- Ojo abierto (icon-open) -->
                    <svg class="icon icon-open" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M12 5C5 5 1 12 1 12s4 7 11 7 11-7 11-7-4-7-11-7zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8z"/>
                    </svg>

                    <!-- Ojo cerrado / tachado (icon-closed) -->
                    <svg class="icon icon-closed" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M2 2l20 20M4.5 4.5C2.9 6.3 1.6 8.5 1 12c0 0 4 7 11 7 2 0 3.8-.4 5.4-1.1M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                    </svg>
                </button>
            </div>

            <label for="confirmar_contraseña">Confirmar contraseña</label>
            <input type="password" id="confirmar_contraseña" name="confirmar_contraseña" required autocomplete="new-password" />

            <div class="requisitos">
                La contraseña debe contener:<br>
                • Al menos 8 caracteres<br>
                • Una letra mayúscula<br>
                • Una letra minúscula<br>
                • Un número<br>
                • Un carácter especial
            </div>

            <button type="submit">Guardar nueva contraseña</button>

            <div class="note">Si tienes problemas para restablecer la contraseña, contacta con el administrador.</div>
        </form>
    </div>

    <script>
    (function(){
        const toggleBtn = document.getElementById('togglePasswordBtn');
        const input = document.getElementById('nueva_contraseña');

        // Inicial: el botón no está activo (contraseña oculta)
        toggleBtn.addEventListener('click', function(e){
            const isHidden = input.type === 'password';
            if(isHidden){
                input.type = 'text';
                toggleBtn.classList.add('active');
                toggleBtn.setAttribute('aria-pressed','true');
                toggleBtn.setAttribute('aria-label','Ocultar contraseña');
            } else {
                input.type = 'password';
                toggleBtn.classList.remove('active');
                toggleBtn.setAttribute('aria-pressed','false');
                toggleBtn.setAttribute('aria-label','Mostrar contraseña');
            }
            // Mantener foco en el botón para accesibilidad
            toggleBtn.focus();
        });

        // Previene que al presionar Enter dentro del botón se envíe el formulario
        toggleBtn.addEventListener('keydown', function(e){
            if(e.key === 'Enter' || e.key === ' '){
                e.preventDefault();
                toggleBtn.click();
            }
        });

        // Validación en cliente
        window.validarPassword = function(){
            const pass = document.getElementById("nueva_contraseña").value;
            const confirm = document.getElementById("confirmar_contraseña").value;
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

            if (pass !== confirm) {
                alert("Las contraseñas no coinciden.");
                return false;
            }

            if (!regex.test(pass)) {
                alert("La contraseña debe tener mínimo 8 caracteres, incluir mayúsculas, minúsculas, números y caracteres especiales.");
                return false;
            }

            return true;
        };
    })();
    </script>
</body>
</html>
