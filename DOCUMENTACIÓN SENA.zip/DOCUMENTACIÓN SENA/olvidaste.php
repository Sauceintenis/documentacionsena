<?php
// olvidaste.php
session_start();

// Generar token CSRF simple (se reutiliza si ya existe)
if (!isset($_SESSION['csrf_reset']) || empty($_SESSION['csrf_reset'])) {
    $_SESSION['csrf_reset'] = bin2hex(random_bytes(32));
}

// Mensajes que pueden llegar por GET: msg=sent | msg=error | msg=invalid
$msg = $_GET['msg'] ?? '';
$msg_text = '';
$msg_type = '';

switch ($msg) {
    case 'sent':
        $msg_text = 'Si el correo está registrado, hemos enviado un enlace de recuperación. Revisa tu bandeja (y carpeta de spam).';
        $msg_type = 'success';
        break;
    case 'invalid':
        $msg_text = 'Solicitud inválida. Intenta nuevamente.';
        $msg_type = 'danger';
        break;
    case 'error':
        $msg_text = 'Ocurrió un error en el servidor. Intenta más tarde.';
        $msg_type = 'danger';
        break;
    default:
        $msg_text = '';
        $msg_type = '';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Recuperar contraseña - SENA</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="CSS/Estilos.css">
    <style>
        .reset-container {
            max-width: 520px;
            margin: 48px auto;
            padding: 22px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.08);
            font-family: Arial, sans-serif;
        }
        .logo { text-align:center; margin-bottom: 12px; }
        h1 { font-size: 20px; margin: 6px 0 12px; text-align:center; color:#2c6b2c; }
        p.lead { text-align:center; color:#555; margin-bottom: 18px; }
        .form-group { margin-bottom: 14px; }
        label { display:block; font-weight:600; margin-bottom:6px; color:#333;}
        input[type="email"] {
            width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px; font-size:14px;
        }
        button.btn {
            background:#4caf50; color:#fff; border:none; padding:10px 14px; border-radius:6px; cursor:pointer; font-weight:700;
        }
        .msg { padding:10px 12px; border-radius:6px; margin-bottom:12px; }
        .msg.success { background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
        .msg.danger { background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; }
        .aux { margin-top:12px; text-align:center; color:#666; font-size:14px; }
        .link { color:#2c6b2c; text-decoration:none; font-weight:600; }
        .small { font-size:13px; color:#666; margin-top:8px; }
    </style>
</head>
<body class="register-page">
    <div class="reset-container" role="main">
        <div class="logo">
            <img src="IMG/Logo.png" alt="Logo" style="height:54px;">
        </div>

        <h1>¿Olvidaste tu contraseña?</h1>
        <p class="lead">Introduce el correo con el que te registraste y te enviaremos un enlace seguro para restablecerla.</p>

        <?php if (!empty($msg_text)): ?>
            <div class="msg <?php echo $msg_type === 'success' ? 'success' : 'danger'; ?>">
                <?php echo htmlspecialchars($msg_text); ?>
            </div>
        <?php endif; ?>

        <form id="resetForm" action="enviar_reset.php" method="post" novalidate>
            <div class="form-group">
                <label for="correo">Correo electrónico</label>
                <input type="email" id="correo" name="correo" placeholder="tu@correo.com" required>
            </div>

            <!-- Token CSRF -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_reset']); ?>">

            <div style="display:flex; gap:10px; align-items:center; justify-content:space-between;">
                <button type="submit" class="btn">Enviar enlace</button>
                <a href="index.php" class="link">Volver al inicio</a>
            </div>

            <div class="small">Si no recibes el correo revisa tu carpeta de spam. El enlace expirará por seguridad.</div>
        </form>
    </div>

    <script>
    (function(){
        const form = document.getElementById('resetForm');
        const email = document.getElementById('correo');

        function validEmail(e) {
            // Regex más flexible: permite subdominios y dominios de 2 a 10 caracteres (.co, .info, .edu.co, etc.)
            const re = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,10}(\.[a-zA-Z]{2,10})?$/;
            return re.test(e);
        }

        form.addEventListener('submit', function(e){
            if (!validEmail(email.value.trim())) {
                e.preventDefault();
                alert('Por favor ingresa un correo válido.');
                email.focus();
                return false;
            }
            const btn = form.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.textContent = 'Enviando...';
        });
    })();
</script>

</body>
</html>
