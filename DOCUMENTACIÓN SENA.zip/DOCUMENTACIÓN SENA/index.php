<?php
require_once 'incluidos/verificar_login.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SENA - Sistema de Documentación</title>
  <link rel="stylesheet" href="CSS/Estilos.css">
</head>
<body class="login-page">
  <div class="login-container fade-in">
      <div class="login-header">
          <div class="sena-logo">
              <img src="IMG/logo.png" alt="SENA Sofia Plus Logo">
          </div>
          <h1 class="login-title">Bienvenido</h1>
          <p class="login-subtitle">Sistema de Gestión Documental SENA</p>
      </div>
      
      <?php
      if (isset($_GET['error'])) {
          echo "<p class='alert alert-danger'>" . htmlspecialchars($_GET['error']) . "</p>";
      }
      if (isset($_GET['success'])) {
          echo "<p class='alert alert-success'>" . htmlspecialchars($_GET['success']) . "</p>";
      }
      ?>

      <form action="validar.php" method="post">
          <div class="form-group">
              <label for="numero_documento">Número de Documento:</label>
              <input type="text" name="numero_documento" id="numero_documento" required>
          </div>
          <div class="form-group">
              <label for="Contraseña">Contraseña:</label>
              <input type="password" name="Contraseña" id="Contraseña" required>
          </div>
          <div class="form-group" style="text-align: left; display: flex; align-items: center; gap: 10px;">
              <input type="checkbox" name="remember" id="remember" style="width: auto; height: auto;">
              <label for="remember" style="margin-bottom: 0; font-weight: normal; color: #555;">Recordar sesión</label>
          </div>
          <button type="submit" class="btn-login">Iniciar Sesión</button>
      </form>
      
      <div class="login-link">
        <a href="Registro.php">¿No tienes cuenta? Regístrate</a>
      </div>
      <div class="login-link">
    <p><a href="olvidaste.php">¿Olvidaste tu contraseña?</a></p>
</div>
  </div>
</body>
</html>
